import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Webhook de check-in (Google Forms -> ERP). Recebe { username, area?, gestor? }.
// Guarda área e gestor no cadastro do usuário na nuvem: nas próximas vezes,
// basta enviar o username que a área e o gestor são reaproveitados.
const CHUNK_SIZE = 16000;
const NUM_CHUNKS = 60;

Deno.serve(async (req) => {
  const cors: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8'
  };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  try {
    const body: any = await req.json().catch(() => ({}));
    const base44 = createClientFromRequest(req);
    const client: any = base44.asServiceRole ?? base44;

    const raw: any = await client.entities.ErpState.list({});
    const records: any[] = Array.isArray(raw) ? raw : (raw?.items ?? raw?.records ?? raw?.data ?? []);
    const current = records[0];

    let payload: any = null;
    if (current) {
      const chunks: string[] = [];
      for (let i = 0; i < NUM_CHUNKS; i++) {
        const c = current[`payload_${i}`];
        if (typeof c === 'string' && c.length > 0) chunks.push(c);
      }
      if (chunks.length > 0) payload = chunks.join('');
      else if (typeof current.payload === 'string') payload = current.payload;
    }
    const state: any = payload ? JSON.parse(payload) : { users: [], logs: [] };
    state.users = state.users || []; state.logs = state.logs || [];

    const username = String(body.username || '').trim().toLowerCase();
    if (!username) return new Response(JSON.stringify({ ok: false, error: 'Usuário não informado' }), { status: 400, headers: cors });

    const emp = state.users.find((u: any) => String(u.username || '').toLowerCase() === username && (u.role === 'COLABORADOR' || u.role === 'OPLOG2'));
    if (!emp) return new Response(JSON.stringify({ ok: false, error: 'Usuário não encontrado' }), { status: 404, headers: cors });
    if (emp.status !== 'ATIVO') return new Response(JSON.stringify({ ok: false, error: `Colaborador está como "${emp.status}"` }), { status: 400, headers: cors });

    // Área e gestor: usa o enviado, senão o que já está lembrado na nuvem
    const area = body.area || emp.area || '';
    const gestor = body.gestor || emp.gestor || '';
    if (!area) return new Response(JSON.stringify({ ok: false, error: 'Área não informada e sem área lembrada' }), { status: 400, headers: cors });

    const todayStr = new Date().toISOString().slice(0, 10);
    if ((state.logs || []).some((l: any) => l.empId === emp.id && l.date === todayStr)) {
      return new Response(JSON.stringify({ ok: false, error: 'Ponto de hoje já registrado', name: emp.name }), { status: 400, headers: cors });
    }

    const isWorkDay = (() => {
      const turma = emp.turma || '';
      if (!turma) return true;
      const date = new Date(todayStr);
      const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000);
      const offsets: any = { 'A': 0, 'B': 1, 'C': 2, 'D': 3 };
      const base = (turma.replace(/[^ABCD]/g, '')[0] as keyof typeof offsets) || 'A';
      return ((dayOfYear + (offsets[base] || 0)) % 6) < 4;
    })();

    const timeStr = new Date().toLocaleTimeString('pt-BR', { hour12: false, timeZone: 'America/Sao_Paulo' });
    const log = { id: Date.now(), empId: emp.id, name: emp.name, gestor, area, date: todayStr, time: timeStr, status: isWorkDay ? 'PRESENTE' : 'HORA EXTRA', source: 'QR_CODE' };
    state.logs = [log, ...state.logs].slice(0, 5000);

    // Lembra área e gestor no cadastro: próximas vezes só o username basta
    // areaAt = timestamp para o merge do painel não reverter com cópia antiga
    for (const u of state.users) {
      if (u.id === emp.id) { u.area = area; u.gestor = gestor; u.areaAt = log.id; }
    }

    const json = JSON.stringify(state);
    if (json.length > CHUNK_SIZE * NUM_CHUNKS) {
      return new Response(JSON.stringify({ ok: false, error: 'Estado maior que a capacidade' }), { status: 413, headers: cors });
    }
    const data: Record<string, string> = {};
    const total = Math.ceil(json.length / CHUNK_SIZE);
    for (let i = 0; i < NUM_CHUNKS; i++) {
      data[`payload_${i}`] = i < total ? json.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE) : '';
    }
    if (current) await client.entities.ErpState.update(current.id, data);
    else await client.entities.ErpState.create(data);

    return new Response(JSON.stringify({ ok: true, name: emp.name, area, gestor, status: log.status, time: timeStr, remembered: !body.area || !body.gestor }), { headers: cors });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || 'Erro interno' }), { status: 500, headers: cors });
  }
});
