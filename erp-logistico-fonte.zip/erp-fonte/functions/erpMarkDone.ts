import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Finaliza pedidos de exportação do ERP: marca como done todos os registros
// pendentes de ErpSheets. Só é chamado depois que o agente gravou com sucesso.
Deno.serve(async (_req) => {
  const cors: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json; charset=utf-8'
  };
  try {
    const base44 = createClientFromRequest(_req);
    const client: any = base44.asServiceRole ?? base44;
    const raw: any = await client.entities.ErpSheets.list({});
    const records: any[] = Array.isArray(raw) ? raw : (raw?.items ?? raw?.records ?? raw?.data ?? []);
    const pending = records.filter((r: any) => r.status === 'pending');
    for (const r of pending) {
      await client.entities.ErpSheets.update(r.id, { status: 'done' });
    }
    return new Response(JSON.stringify({ ok: true, finalized: pending.length }), { headers: cors });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || 'Erro interno' }), { status: 500, headers: cors });
  }
});
