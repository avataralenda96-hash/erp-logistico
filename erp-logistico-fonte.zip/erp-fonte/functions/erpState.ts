import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Estado do ERP Logístico: um único registro, dividido em blocos de 16.000 caracteres
// (limite por campo da plataforma é ~25KB). Gravação atômica em um único update.
const CHUNK_SIZE = 16000;
const NUM_CHUNKS = 60;

Deno.serve(async (req) => {
  const cors: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8'
  };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  try {
    const body: any = await req.json().catch(() => ({}));
    const action = body.action || 'get';

    const base44 = createClientFromRequest(req);
    const client: any = base44.asServiceRole ?? base44;

    const raw: any = await client.entities.ErpState.list({});
    const records: any[] = Array.isArray(raw) ? raw : (raw?.items ?? raw?.records ?? raw?.data ?? []);
    const current = records[0];

    if (action === 'get') {
      let payload = null;
      if (current) {
        const chunks: string[] = [];
        for (let i = 0; i < NUM_CHUNKS; i++) {
          const c = current[`payload_${i}`];
          if (typeof c === 'string' && c.length > 0) chunks.push(c);
        }
        if (chunks.length > 0) payload = chunks.join('');
        else if (typeof current.payload === 'string') payload = current.payload; // compatibilidade
      }
      return new Response(JSON.stringify({ ok: true, payload }), { headers: cors });
    }

    if (action === 'save') {
      let payload = typeof body.payload === 'string' ? body.payload : JSON.stringify(body.payload ?? {});

      // MERGE: o painel só tem a visão do momento em que carregou. Antes de gravar,
      // une o que chegou com o que já está na nuvem para não apagar pontos que
      // chegaram via QR Code/webhook depois que o painel foi aberto.
      try {
        if (body.force) throw new Error('force'); // substituicao total, sem uniao (manutencao)
        const incoming: any = JSON.parse(payload);
        let serverState: any = null;
        if (current) {
          const chunks: string[] = [];
          for (let i = 0; i < NUM_CHUNKS; i++) {
            const c = current[`payload_${i}`];
            if (typeof c === 'string' && c.length > 0) chunks.push(c);
          }
          if (chunks.length > 0) serverState = JSON.parse(chunks.join(''));
        }

        if (serverState) {
          const mergeArr = (inc: any[] = [], srv: any[] = [], key = 'id') => {
            const map = new Map<any, any>();
            for (const it of srv) map.set(it?.[key], it);
            for (const it of inc) map.set(it?.[key], it); // quem chegou por último vence no conflito
            return Array.from(map.values()).slice(-5000);
          };
          incoming.logs = mergeArr(incoming.logs, serverState.logs).sort((a: any, b: any) =>
            (String(b.date).localeCompare(String(a.date))) || (Number(b.id) - Number(a.id)));
          incoming.incidents = mergeArr(incoming.incidents, serverState.incidents);
          incoming.sosRequests = mergeArr(incoming.sosRequests, serverState.sosRequests);
          incoming.areaReports = mergeArr(incoming.areaReports, serverState.areaReports);
          incoming.pwdRequests = mergeArr(incoming.pwdRequests, serverState.pwdRequests);
          incoming.sinergias = mergeArr(incoming.sinergias, serverState.sinergias);
          incoming.dotReports = mergeArr(incoming.dotReports, serverState.dotReports); // hora a hora (DOT)
          if (incoming.dotSchedule == null && serverState.dotSchedule) incoming.dotSchedule = serverState.dotSchedule;
          // EXTRA OPS 2: marcação "de extra" de quem está de folga; a marcação mais nova por Ops 2 vence
          {
            const srv: any = serverState.extraOps || {};
            const inc: any = incoming.extraOps || {};
            const out: any = { ...srv };
            for (const k of Object.keys(inc)) {
              const iAt = inc[k]?.at || 0, sAt = srv[k]?.at || 0;
              if (iAt >= sAt) out[k] = inc[k]; else out[k] = srv[k];
            }
            incoming.extraOps = out;
          }

          // Usuários: cadastro local vence, mas área/gestor seguem o timestamp mais novo
          // (o webhook do QR grava areaAt; painéis antigos não têm esse campo e perdem)
          const srvUsers = new Map<any, any>((serverState.users || []).map((u: any) => [u.id, u]));
          incoming.users = (incoming.users || []).map((u: any) => {
            const s = srvUsers.get(u.id);
            if (!s) return u;
            const sAt = typeof s.areaAt === 'number' ? s.areaAt : 0;
            const iAt = typeof u.areaAt === 'number' ? u.areaAt : 0;
            if (sAt > iAt && (s.area || s.gestor)) {
              return { ...u, area: s.area || u.area, gestor: s.gestor || u.gestor, areaAt: sAt };
            }
            return u;
          });
          payload = JSON.stringify(incoming);
        }
      } catch (_mergeErr) { /* se algo falhar no merge, grava como veio */ }

      if (payload.length > CHUNK_SIZE * NUM_CHUNKS) {
        return new Response(JSON.stringify({ ok: false, error: 'Estado maior que a capacidade (reduza o histórico)' }), { status: 413, headers: cors });
      }
      const data: Record<string, string> = {};
      const total = Math.ceil(payload.length / CHUNK_SIZE);
      for (let i = 0; i < NUM_CHUNKS; i++) {
        data[`payload_${i}`] = i < total ? payload.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE) : '';
      }
      if (current) {
        await client.entities.ErpState.update(current.id, data);
      } else {
        await client.entities.ErpState.create(data);
      }
      return new Response(JSON.stringify({ ok: true, chunks: total }), { headers: cors });
    }

    return new Response(JSON.stringify({ ok: false, error: 'Ação inválida' }), { status: 400, headers: cors });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || 'Erro interno' }), { status: 500, headers: cors });
  }
});
