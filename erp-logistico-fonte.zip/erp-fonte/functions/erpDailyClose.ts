import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FECHAMENTO DIÁRIO do ERP (23:30 America/Sao_Paulo):
//  1. Exporta o dia para o Google Sheets oficial (aba "DD-MM-AAAA"):
//     nome, LDAP, função, turma, TL, área de hoje, ponto de hoje, próximas folgas.
//  2. Exporta o HORA A HORA (DOT): por hora 17-23, responsável, DOT, perdas,
//     canalização e motivo do dispatched.
//  3. SÓ SE a gravação der certo, limpa as informações do dia (nova divisão amanhã):
//     área dos usuários (areaAt bumpado para não voltar no merge), delegações Ops 2,
//     sinergias, jantas, coberturas, SOS, reportes de área e o hora a hora (DOT).
//     Mantém: logs (histórico), ocorrências, cadastro e checkinErrors.
// body.test = true -> grava na aba TESTE-FECHAMENTO e NÃO altera nada (diagnóstico).
const CHUNK_SIZE = 16000;
const NUM_CHUNKS = 60;

Deno.serve(async (req) => {
  const cors: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8'
  };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  try {
    const body: any = await req.json().catch(() => ({}));
    const isTest = body.test === true;

    const base44 = createClientFromRequest(req);
    const client: any = base44.asServiceRole ?? base44;

    const localDateStr = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
    const localTimeStr = () => new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());

    // --- 1. carrega estado ---
    const raw: any = await client.entities.ErpState.list({});
    const records: any[] = Array.isArray(raw) ? raw : (raw?.items ?? raw?.records ?? raw?.data ?? []);
    const current = records[0];
    let state: any = null;
    if (current) {
      const chunks: string[] = [];
      for (let i = 0; i < NUM_CHUNKS; i++) {
        const c = current[`payload_${i}`];
        if (typeof c === 'string' && c.length > 0) chunks.push(c);
      }
      if (chunks.length > 0) state = JSON.parse(chunks.join(''));
    }
    if (!state || !Array.isArray(state.users)) throw new Error('Estado do ERP não encontrado na nuvem');

    const hoje = isTest ? String(body.date || localDateStr()) : localDateStr();
    const [y, m, d] = hoje.split('-');
    const tab = isTest ? 'TESTE-FECHAMENTO' : `${d}-${m}-${y}`;

    // --- 2. escala real de folga (ciclo de 28 dias, ref. 01/08/2026; AA, AB, AC, AD) ---
    const FOLGA_CICLO_28: any = {"AA": [2, 3, 9, 15, 20, 21, 25, 26], "AB": [0, 4, 5, 9, 10, 16, 22, 27], "AC": [1, 6, 7, 11, 12, 16, 17, 23], "AD": [2, 8, 13, 14, 18, 19, 23, 24]};
    const isWorkDay = (turma: string, iso: string) => {
      const tt = String(turma || '').toUpperCase().replace(/[^ABCD]/g, '');
      const folgas = tt ? FOLGA_CICLO_28['A' + tt[tt.length - 1]] : null;
      if (!folgas) return true;
      const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
      const dias = Math.round((Date.UTC(y, m - 1, d) - Date.UTC(2026, 7, 1)) / 86400000);
      return !folgas.includes(((dias % 28) + 28) % 28);
    };
    const proximasFolgas = (turma: string, qtd = 3) => {
      const out: string[] = [];
      const dt = new Date(hoje + 'T12:00:00Z');
      for (let i = 1; i <= 40 && out.length < qtd; i++) {
        const iso = new Date(dt.getTime() + i * 86400000).toISOString().slice(0, 10);
        if (!isWorkDay(turma, iso)) out.push(iso.slice(8, 10) + '/' + iso.slice(5, 7));
      }
      return out.join(', ');
    };

    // --- 3. planilha oficial ---
    const ptrRaw: any = await client.entities.ErpSheets.list({});
    const ptrRecs: any[] = Array.isArray(ptrRaw) ? ptrRaw : (ptrRaw?.items ?? ptrRaw?.records ?? ptrRaw?.data ?? []);
    const pointer = ptrRecs.find((r: any) => r.status === 'POINTER' && r.spreadsheet_id);
    if (!pointer) throw new Error('Planilha oficial não encontrada (registro POINTER ausente)');
    const SID = pointer.spreadsheet_id;

    const conn = await client.connectors.getConnection('googlesheets');
    const token = conn?.accessToken || conn?.access_token;
    if (!token) throw new Error('Conector Google Sheets sem token');
    const SH = (m: string, u: string, o?: any) => fetch(`https://sheets.googleapis.com/v4/spreadsheets/${SID}${u}`, {
      method: m,
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: o ? JSON.stringify(o) : undefined
    });

    // cria a aba do dia se não existir
    const meta = await (await SH('GET', `?fields=sheets(properties(title))`)).json();
    const titles: string[] = (meta.sheets || []).map((x: any) => x.properties.title);
    if (!titles.includes(tab)) {
      await SH('POST', ':batchUpdate', { requests: [{ addSheet: { properties: { title: tab } } }] });
    }

    // --- 4. linhas ---
    const fmt = hoje.split('-');
    const rows: any[][] = [
      [`FECHAMENTO DO DIA ${fmt[2]}/${fmt[1]}/${fmt[0]}`],
      [`Gerado automaticamente em ${localTimeStr()} (horário de Brasília)`],
      [],
      ['NOME', 'LDAP', 'FUNCAO', 'TURMA', 'TL', 'AREA HOJE', 'PONTO HOJE', 'HORA', 'ORIGEM', 'PROXIMAS FOLGAS']
    ];
    const logsHoje = (state.logs || []).filter((l: any) => l.date === hoje);
    for (const u of state.users) {
      if (u.role !== 'COLABORADOR' && u.role !== 'OPLOG2') continue;
      const log = logsHoje.find((l: any) => l.empId === u.id || l.name === u.name);
      rows.push([
        u.name, u.username, u.role === 'OPLOG2' ? 'OPS 2' : 'COLABORADOR', u.turma || '', u.gestor || '',
        u.area || '(sem divisão)', log ? log.status : 'SEM PONTO', log ? log.time : '', log ? log.source : '',
        proximasFolgas(u.turma)
      ]);
    }

    // --- 4b. HORA A HORA (DOT) ---
    rows.push([], [`HORA A HORA (DOT) - ${fmt[2]}/${fmt[1]}`],
      ['HORA', 'RESPONSAVEL', 'DOT DA HORA', 'DOT ACUMULADO', 'PERDAS DA HORA', 'PERDAS GERAIS', 'CANALIZACAO', 'MOTIVO DISPATCHED']);
    const sched = state.dotSchedule && state.dotSchedule.date === hoje ? (state.dotSchedule.slots || {}) : {};
    const nameOf = (id: string) => (state.users.find((u: any) => u.id === id)?.name) || '';
    for (let h = 17; h <= 23; h++) {
      const rep = (state.dotReports || []).find((r: any) => r.date === hoje && Number(r.hour) === h);
      rows.push([
        h + 'h', nameOf(sched[h]) || '(sem responsavel)',
        rep ? rep.dotHora : '', rep ? rep.dotAcum : '', rep ? rep.perdasHora : '', rep ? rep.perdasGerais : '',
        rep ? rep.canalizacao : '', rep ? rep.motivo : ''
      ]);
    }

    const vr = await (await SH('PUT', `/values/${encodeURIComponent(tab)}!A1?valueInputOption=RAW`, { values: rows })).json();
    if (vr.error) throw new Error('Sheets: ' + vr.error.message);

    // --- 5. limpeza do dia (somente produção) ---
    let limpo = false;
    if (!isTest) {
      const agora = Date.now();
      state.users = state.users.map((u: any) => (u.area ? { ...u, area: '', areaAt: agora } : u));
      state.ops2Assignments = {};
      state.sinergias = [];
      state.extraOps = {}; // marcação diária de Ops 2 de extra (folga trabalhando)
      state.lunchBreaks = {};
      state.lunchCoverage = {};
      state.sosRequests = [];
      state.areaReports = [];
      state.dotSchedule = null;
      state.dotReports = [];
      limpo = true;
    }

    // --- 6. grava estado (substituição total, sem merge) ---
    if (limpo) {
      const payload = JSON.stringify(state);
      if (payload.length > CHUNK_SIZE * NUM_CHUNKS) throw new Error('Estado grande demais');
      const data: Record<string, any> = {};
      for (let i = 0; i < NUM_CHUNKS; i++) data[`payload_${i}`] = '';
      for (let i = 0; i * CHUNK_SIZE < payload.length; i++) {
        data[`payload_${i}`] = payload.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
      }
      await client.entities.ErpState.update(current.id, data);
    }

    return new Response(JSON.stringify({
      ok: true, test: isTest, date: hoje, tab,
      colaboradores: rows.filter(r => r.length === 10).length - 1,
      pontos: logsHoje.length, sheetUrl: `https://docs.google.com/spreadsheets/d/${SID}/edit`, limpo
    }), { headers: cors });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e && (e as Error).message || e) }), { status: 500, headers: cors });
  }
});
