import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Ponte ERP -> Google Sheets:
//  - action 'request': o app cria um registro pendente com as linhas do relatório
//    (divididas em blocos). Um workflow é acionado e o agente escreve na planilha.
//  - action 'status': consulta o estado de um pedido e a URL da planilha oficial.
const CHUNK_SIZE = 16000;
const NUM_CHUNKS = 4;

Deno.serve(async (req) => {
  const cors: Record<string, string> = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8'
  };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  try {
    const body: any = await req.json().catch(() => ({}));
    const action = body.action || 'status';

    const base44 = createClientFromRequest(req);
    const client: any = base44.asServiceRole ?? base44;

    if (action === 'request') {
      const rowsJson = JSON.stringify(Array.isArray(body.rows) ? body.rows : []);
      if (rowsJson.length > CHUNK_SIZE * NUM_CHUNKS) {
        return new Response(JSON.stringify({ ok: false, error: 'Relatório grande demais' }), { status: 413, headers: cors });
      }
      const data: Record<string, any> = {
        status: 'pending',
        scope: String(body.scope || 'master').slice(0, 100),
        requested_by: String(body.requestedBy || '').slice(0, 100),
        export_date: String(body.exportDate || '').slice(0, 20),
        title: String(body.title || '').slice(0, 200),
      };
      const total = Math.ceil(rowsJson.length / CHUNK_SIZE);
      for (let i = 0; i < NUM_CHUNKS; i++) {
        data[`rows_${i}`] = i < total ? rowsJson.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE) : '';
      }
      const created: any = await client.entities.ErpSheets.create(data);
      return new Response(JSON.stringify({ ok: true, id: created?.id }), { headers: cors });
    }

    if (action === 'status') {
      const raw: any = await client.entities.ErpSheets.list({});
      const records: any[] = Array.isArray(raw) ? raw : (raw?.items ?? raw?.records ?? raw?.data ?? []);
      const pointer = records.find((r: any) => r.spreadsheet_id && r.status === 'POINTER');
      if (body.id) {
        const rec = records.find((r: any) => r.id === body.id);
        return new Response(JSON.stringify({
          ok: true,
          status: rec?.status || 'unknown',
          url: pointer?.spreadsheet_url || null
        }), { headers: cors });
      }
      return new Response(JSON.stringify({ ok: true, status: 'none', url: pointer?.spreadsheet_url || null }), { headers: cors });
    }

    return new Response(JSON.stringify({ ok: false, error: 'Ação inválida' }), { status: 400, headers: cors });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || 'Erro interno' }), { status: 500, headers: cors });
  }
});
