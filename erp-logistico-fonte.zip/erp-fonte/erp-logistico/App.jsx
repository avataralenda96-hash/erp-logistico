import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Users, Shield, AlertTriangle, Clock, Map, User, 
  Search, Lock, Unlock, ArrowRight, MessageSquare, 
  CheckCircle, XCircle, Bell, ArrowUpCircle, FileText,
  QrCode, LogOut, Settings, Plus, RefreshCw, Printer, ExternalLink,
  CalendarDays
} from 'lucide-react';

// --- MOCK DATABASE ---
// Adicionei os usuários com a flag "mustChangePwd: true" para forçar a troca no primeiro login.
const INITIAL_USERS = [
  // --- MASTER ---
  { id: 'm1', name: 'ADMINISTRADOR MESTRE', role: 'MASTER', username: 'master.admin', password: '123', mustChangePwd: true, photo: 'https://ui-avatars.com/api/?name=ADMINISTRADOR+MESTRE' },
  // --- GESTORES (Team Leaders + supervisão) ---
  { id: 'g1', name: 'MICHAEL DAVID DE OLIVEIRA SILVA', role: 'GESTOR', status: 'ATIVO', turma: 'AC', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'michasilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MICHAEL+DAVID' },
  { id: 'g2', name: 'GABRIEL AMORIM DE SOUZA', role: 'GESTOR', status: 'ATIVO', turma: 'AB', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'gaamsouza', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=GABRIEL+AMORIM' },
  { id: 'g3', name: 'LUCAS LOPES DA SILVA', role: 'GESTOR', status: 'ATIVO', turma: 'AA', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'lucslopes', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=LUCAS+LOPES' },
  { id: 'g4', name: 'JHONATAN ARIEL LOURENCON DA SILVA', role: 'GESTOR', status: 'ATIVO', turma: 'AB', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'jlndsilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JHONATAN+ARIEL' },
  { id: 'g5', name: 'THIAGO DA SILVA AMI', role: 'GESTOR', status: 'ATIVO', turma: 'AB', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'tamiami', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=THIAGO+DA' },
  { id: 'g6', name: 'TIAGO DORETTO DE JESUS', role: 'GESTOR', status: 'ATIVO', username: 'tiago.doretto', password: '123', mustChangePwd: true, photo: 'https://ui-avatars.com/api/?name=TIAGO+DORETTO' },
  { id: 'g7', name: 'IGOR HENRIQUE DO NASCIMENTO', role: 'GESTOR', status: 'ATIVO', gestor: 'TIAGO DORETTO DE JESUS', gestorId: 'g6', username: 'igor.nascimento', password: '123', mustChangePwd: true, photo: 'https://ui-avatars.com/api/?name=IGOR+HENRIQUE' },
  // --- OPLOG 3 ---
  { id: 'op3_jezsantos', name: 'JEZIEL FERNANDES SANTOS', role: 'OPLOG3', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'jezsantos', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JEZIEL+FERNANDES' },
  { id: 'op3_kaandrade', name: 'KAIO GUILHERME DE ANDRADE', role: 'OPLOG3', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'kaandrade', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=KAIO+GUILHERME' },
  { id: 'op3_yancastr', name: 'YAN FELIPE DA SILVA CASTRO', role: 'OPLOG3', status: 'ATIVO', turma: 'AC', gestor: 'IGOR HENRIQUE DO NASCIMENTO', gestorId: 'g7', username: 'yancastr', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=YAN+FELIPE' },
  // --- OPLOG 2 ---
  { id: 'op2_alaarodrigue', name: 'ALAN AMARAL RODRIGUES', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'alaarodrigue', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=ALAN+AMARAL' },
  { id: 'op2_amjcosta', name: 'AMARO COSTA PEREIRA JUNIOR', role: 'OPLOG2', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'amjcosta', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=AMARO+COSTA' },
  { id: 'op2_andjpereira', name: 'ANDERSON JOSE DA SILVA PEREIRA', role: 'OPLOG2', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'andjpereira', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=ANDERSON+JOSE' },
  { id: 'op2_camiferreira', name: 'CAMILA APARECIDA ROMUALDO FERREIRA', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'camiferreira', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=CAMILA+APARECIDA' },
  { id: 'op2_cdalves', name: 'CARLOS DANIEL SILVA ALVES', role: 'OPLOG2', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'cdalves', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=CARLOS+DANIEL' },
  { id: 'op2_davisdosilva', name: 'DAVIDSON CARDOSO DA SILVA', role: 'OPLOG2', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'davisdosilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=DAVIDSON+CARDOSO' },
  { id: 'op2_ememonteiro', name: 'EMERSON MONTEIRO GROTA', role: 'OPLOG2', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'ememonteiro', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=EMERSON+MONTEIRO' },
  { id: 'op2_ericvsilva', name: 'ERICA VANESSA DA SILVA', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'ericvsilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=ERICA+VANESSA' },
  { id: 'op2_evipereira', name: 'EVILYN PEREIRA DA SILVA', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'evipereira', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=EVILYN+PEREIRA' },
  { id: 'op2_gfcardoso', name: 'GABRIEL FOICINHA CARDOSO', role: 'OPLOG2', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'gfcardoso', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=GABRIEL+FOICINHA' },
  { id: 'op2_gcardeal', name: 'GABRIELA CARDEAL GONCALVES', role: 'OPLOG2', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'gcardeal', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=GABRIELA+CARDEAL' },
  { id: 'op2_gdgomes', name: 'GUILHERME GOMES DOS SANTOS DIAS', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'gdgomes', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=GUILHERME+GOMES' },
  { id: 'op2_igorrib', name: 'IGOR RIBEIRO LUZ', role: 'OPLOG2', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'igorrib', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=IGOR+RIBEIRO' },
  { id: 'op2_jvpreite', name: 'JOAO VINICIUS PACHECO PREITE', role: 'OPLOG2', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'jvpreite', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JOAO+VINICIUS' },
  { id: 'op2_joseccsilva', name: 'JOSE CARLOS CORDEIRO SILVA', role: 'OPLOG2', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'joseccsilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JOSE+CARLOS' },
  { id: 'op2_kosoares', name: 'KAUAN FREITAS OLIVEIRA SOARES', role: 'OPLOG2', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'kosoares', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=KAUAN+FREITAS' },
  { id: 'op2_kethelpsilva', name: 'KETHELYN PAULA DA SILVA', role: 'OPLOG2', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'kethelpsilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=KETHELYN+PAULA' },
  { id: 'op2_thehsilva', name: 'MATHEUS HENRIQUE DE OLIVEIRA SILVA', role: 'OPLOG2', status: 'FÉRIAS', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'thehsilva', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MATHEUS+HENRIQUE' },
  { id: 'op2_salsantos', name: 'SABRINA LEANDRO DOS SANTOS', role: 'OPLOG2', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'salsantos', password: '123', mustChangePwd: true, emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=SABRINA+LEANDRO' },
  // --- REP 2 / COLABORADORES ---
  { id: 'c_alanbsantos', name: 'ALAN BARBOSA DOS SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'alanbsantos', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ALAN+BARBOSA' },
  { id: 'c_lesosilva', name: 'ALESSANDRA DE OLIVEIRA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'lesosilva', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=ALESSANDRA+DE' },
  { id: 'c_algspereira', name: 'ALGACIR PEREIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'algspereira', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ALGACIR+PEREIRA' },
  { id: 'c_aallopes', name: 'ALINE LOPES PEIXOTO DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'aallopes', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ALINE+LOPES' },
  { id: 'c_afsales', name: 'ALLAN FERREIRA DE SALES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'afsales', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ALLAN+FERREIRA' },
  { id: 'c_aafsilva', name: 'AMANDA FERREIRA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'aafsilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=AMANDA+FERREIRA' },
  { id: 'c_anabgomes', name: 'ANA BEATRIZ FERREIRA GOMES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'anabgomes', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ANA+BEATRIZ' },
  { id: 'c_nacasoares', name: 'ANA CAROLINA SOARES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'nacasoares', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ANA+CAROLINA' },
  { id: 'c_aqramos', name: 'ANA CAROLINY QUIRINO RAMOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'aqramos', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=ANA+CAROLINY' },
  { id: 'c_anddgoncalve', name: 'ANDERSON DANTAS GONCALVES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'anddgoncalve', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=ANDERSON+DANTAS' },
  { id: 'c_amnaves', name: 'ANDRE MACIEL NAVES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'amnaves', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=ANDRE+MACIEL' },
  { id: 'c_ntoniosilva', name: 'ANTONIO CARLOS PEREIRA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'ntoniosilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ANTONIO+CARLOS' },
  { id: 'c_arorocha', name: 'ARIANE OLIVEIRA ROCHA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'arorocha', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ARIANE+OLIVEIRA' },
  { id: 'c_arleisrogarc', name: 'ARLEIS ROSALES GARCIA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'arleisrogarc', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ARLEIS+ROSALES' },
  { id: 'c_bcoelcoel', name: 'BRUNO COELHO SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'bcoelcoel', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=BRUNO+COELHO' },
  { id: 'c_runcarvalho', name: 'BRUNO MARQUES DOS SANTOS CARVALHO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'runcarvalho', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=BRUNO+MARQUES' },
  { id: 'c_aiossantos', name: 'CAIO ARAUJO DOS SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'aiossantos', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=CAIO+ARAUJO' },
  { id: 'c_camrmiranda', name: 'CAMILA RIBEIRO MIRANDA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'camrmiranda', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=CAMILA+RIBEIRO' },
  { id: 'c_camvitvitori', name: 'CAMILI VITORIA GOULART', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'camvitvitori', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=CAMILI+VITORIA' },
  { id: 'c_cfcorreia', name: 'CARLA FERREIRA CORREIA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'cfcorreia', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=CARLA+FERREIRA' },
  { id: 'c_carosouza', name: 'CARLOS EDUARDO DE OLIVEIRA SOUZA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'carosouza', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=CARLOS+EDUARDO' },
  { id: 'c_celsojasilva', name: 'CELSO JOSE ALVES DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'celsojasilva', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=CELSO+JOSE' },
  { id: 'c_cilima', name: 'CINIELE SILVA VIEIRA DE LIMA', role: 'COLABORADOR', status: 'LIC. MATERNIDADE', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'cilima', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=CINIELE+SILVA' },
  { id: 'c_laudidsantos', name: 'CLAUDIO DOS SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'laudidsantos', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=CLAUDIO+DOS' },
  { id: 'c_danielalalve', name: 'DANIEL ALVES CARVALHO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'danielalalve', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=DANIEL+ALVES' },
  { id: 'c_dessousa', name: 'DESIDERIA NASCIMENTO PEREIRA DE SOUSA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'dessousa', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=DESIDERIA+NASCIMENTO' },
  { id: 'c_dorsousa', name: 'DORALICE GERALDA DE SOUSA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'dorsousa', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=DORALICE+GERALDA' },
  { id: 'c_erralves', name: 'ERICK RODRIGUES ALVES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'erralves', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ERICK+RODRIGUES' },
  { id: 'c_evisilsilva', name: 'EVILLYN VITORIA IVO DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'evisilsilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=EVILLYN+VITORIA' },
  { id: 'c_fabimedeiros', name: 'FABIOLA GINDRE DE MEDEIROS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'fabimedeiros', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=FABIOLA+GINDRE' },
  { id: 'c_fssampaio', name: 'FERNANDA SAMPAIO DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'fssampaio', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=FERNANDA+SAMPAIO' },
  { id: 'c_fernandosaol', name: 'FERNANDO SALES DE OLIVEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'fernandosaol', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=FERNANDO+SALES' },
  { id: 'c_francisjesus', name: 'FRANCISCO FERNANDO DE JESUS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'francisjesus', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=FRANCISCO+FERNANDO' },
  { id: 'c_ghsantossilv', name: 'GABRIEL HENRIQUE DOS SANTOS SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'ghsantossilv', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=GABRIEL+HENRIQUE' },
  { id: 'c_gmarcial', name: 'GABRIELE LARISSA MARCIAL DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'gmarcial', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=GABRIELE+LARISSA' },
  { id: 'c_gccosta', name: 'GILBERTO COSTA', role: 'COLABORADOR', status: 'FÉRIAS', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'gccosta', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=GILBERTO+COSTA' },
  { id: 'c_giovitoria', name: 'GIOVANA VITORIA CHIROV DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'giovitoria', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=GIOVANA+VITORIA' },
  { id: 'c_gpfernandes', name: 'GLEIDERSON PERES FERNANDES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'gpfernandes', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=GLEIDERSON+PERES' },
  { id: 'c_gustavobesil', name: 'GUSTAVO BEZERRA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'gustavobesil', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=GUSTAVO+BEZERRA' },
  { id: 'c_ggmoura', name: 'GUSTAVO GABRIEL PESCE MOURA', role: 'COLABORADOR', status: 'INATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'ggmoura', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=GUSTAVO+GABRIEL' },
  { id: 'c_guhsantos', name: 'GUSTHAVO HENRIQUE DE CASTRO SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'guhsantos', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=GUSTHAVO+HENRIQUE' },
  { id: 'c_hispereira', name: 'HUDSON BRUNO PEREIRA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'hispereira', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=HUDSON+BRUNO' },
  { id: 'c_ifrois', name: 'ISAAC SOUSA FROIS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'ifrois', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ISAAC+SOUSA' },
  { id: 'c_jajccampos', name: 'JAIRO FELIX DE SOUZA CAMPOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'jajccampos', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JAIRO+FELIX' },
  { id: 'c_jsilvamaciel', name: 'JESSICA DA SILVA MACIEL', role: 'COLABORADOR', status: 'LIC. MATERNIDADE', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'jsilvamaciel', emb: 'VENCIDO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JESSICA+DA' },
  { id: 'c_jessicdsilva', name: 'JESSICA PATRICIA DA SILVA', role: 'COLABORADOR', status: 'FÉRIAS', turma: 'AB', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'jessicdsilva', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JESSICA+PATRICIA' },
  { id: 'c_sicarodrigue', name: 'JESSICA RODRIGUES DOS SANTOS ROCHA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'sicarodrigue', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JESSICA+RODRIGUES' },
  { id: 'c_joaovalves', name: 'JOAO VITOR ALVES DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'joaovalves', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JOAO+VITOR' },
  { id: 'c_jocssouza', name: 'JOCILENE SOUZA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'jocssouza', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=JOCILENE+SOUZA' },
  { id: 'c_jonmendes', name: 'JONATHAN MENDES NEGRAO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'jonmendes', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=JONATHAN+MENDES' },
  { id: 'c_jhenrfons', name: 'JOSE HENRIQUE FONSECA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'jhenrfons', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JOSE+HENRIQUE' },
  { id: 'c_jumnasciment', name: 'JULIA MONCAO DO NASCIMENTO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'jumnasciment', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=JULIA+MONCAO' },
  { id: 'c_jjhonorato', name: 'JULIANA KELI HONORATO', role: 'COLABORADOR', status: 'FÉRIAS', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'jjhonorato', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=JULIANA+KELI' },
  { id: 'c_jjccesar', name: 'JULIO CESAR NUNES PEREIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'jjccesar', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=JULIO+CESAR' },
  { id: 'c_kmvictor', name: 'KAIQUE MEIRA VICTOR', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'kmvictor', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=KAIQUE+MEIRA' },
  { id: 'c_karolsilva', name: 'KAROLINE FERNANDES DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'karolsilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=KAROLINE+FERNANDES' },
  { id: 'c_karollisilva', name: 'KAROLLINY SILVA CAMPOLINO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'karollisilva', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=KAROLLINY+SILVA' },
  { id: 'c_kensantos', name: 'KENIA VITORIA DOS SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'kensantos', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=KENIA+VITORIA' },
  { id: 'c_lcocuzza', name: 'LARA DUARTE COCUZZA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'lcocuzza', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=LARA+DUARTE' },
  { id: 'c_lasbraga', name: 'LARISSA SOUZA BRAGA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'lasbraga', emb: 'SEM TREINAMENTO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=LARISSA+SOUZA' },
  { id: 'c_arissasantos', name: 'LARISSA VALERIO SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'arissasantos', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=LARISSA+VALERIO' },
  { id: 'c_llbarreto', name: 'LAYSA LIMA BARRETO', role: 'COLABORADOR', status: 'LIC. MATERNIDADE', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'llbarreto', emb: 'VENCIDO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=LAYSA+LIMA' },
  { id: 'c_leandrobafer', name: 'LEANDRO BATISTA FERREIRA DE LIMA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'leandrobafer', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=LEANDRO+BATISTA' },
  { id: 'c_leonardososa', name: 'LEONARDO DE SOUZA SANTANA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'leonardososa', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=LEONARDO+DE' },
  { id: 'c_onssilva', name: 'LEONARDO FERREIRA DOS SANTOS SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'onssilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=LEONARDO+FERREIRA' },
  { id: 'c_letdsilva', name: 'LETICIA CARDOSO DA SILVA', role: 'COLABORADOR', status: 'AFASTADO INSS', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'letdsilva', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=LETICIA+CARDOSO' },
  { id: 'c_lucasvieira', name: 'LUCAS MARINS VIEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'lucasvieira', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=LUCAS+MARINS' },
  { id: 'c_lucaspereira', name: 'LUCAS PEREIRA DA CRUZ', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'lucaspereira', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=LUCAS+PEREIRA' },
  { id: 'c_macksuelmour', name: 'MACKSUEL DOMINGOS MOURA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'macksuelmour', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MACKSUEL+DOMINGOS' },
  { id: 'c_mancfilho', name: 'MANOEL CARLOS SANTOS DA CRUZ FILHO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'mancfilho', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MANOEL+CARLOS' },
  { id: 'c_mrcandido', name: 'MARCIO RODRIGUES CANDIDO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'mrcandido', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=MARCIO+RODRIGUES' },
  { id: 'c_mcaner', name: 'MARCOS VINICIUS PASSIANI VILAS BOAS CANER', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'mcaner', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MARCOS+VINICIUS' },
  { id: 'c_mariaedteixe', name: 'MARIA EDUARDA AGUIAR TEIXEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'mariaedteixe', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MARIA+EDUARDA' },
  { id: 'c_mgama', name: 'MARIA JULIA GAMA DE SOUZA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'mgama', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MARIA+JULIA' },
  { id: 'c_mariakbatist', name: 'MARIA KEVILLY DA SILVA BATISTA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'mariakbatist', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MARIA+KEVILLY' },
  { id: 'c_marinaraosil', name: 'MARINARA OLIVEIRA DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'marinaraosil', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MARINARA+OLIVEIRA' },
  { id: 'c_mmaandrade', name: 'MATHEUS ANDRADE DE AZEVEDO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'mmaandrade', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MATHEUS+ANDRADE' },
  { id: 'c_matheferreir', name: 'MATHEUS CAVALCANTE FERREIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'matheferreir', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MATHEUS+CAVALCANTE' },
  { id: 'c_mauricmartin', name: 'MAURICIO MARTINS LEAL', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'mauricmartin', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MAURICIO+MARTINS' },
  { id: 'c_milainsilva', name: 'MILAINE DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'milainsilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MILAINE+DA' },
  { id: 'c_milslima', name: 'MILCA SENA LIMA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'milslima', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=MILCA+SENA' },
  { id: 'c_monicapereir', name: 'MONICA LOUYSE PEREIRA PINHEIRO SANTANA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'monicapereir', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=MONICA+LOUYSE' },
  { id: 'c_naacsouza', name: 'NAARA LAIANE CARDOSO SOUZA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'naacsouza', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=NAARA+LAIANE' },
  { id: 'c_nscamargo', name: 'NATALIA DA SILVA CAMARGO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'nscamargo', emb: 'VENCIDO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=NATALIA+DA' },
  { id: 'c_atanssilva', name: 'NATAN DA SILVA ALVES', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'atanssilva', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=NATAN+DA' },
  { id: 'c_niursilva', name: 'NIULSA RIBEIRO DE CARVALHO SILVA', role: 'COLABORADOR', status: 'FÉRIAS', turma: 'AD', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'niursilva', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=NIULSA+RIBEIRO' },
  { id: 'c_oireireno', name: 'OTAVIO IRENO DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'oireireno', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=OTAVIO+IRENO' },
  { id: 'c_paulocsantos', name: 'PAULO CESAR SANTOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'paulocsantos', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=PAULO+CESAR' },
  { id: 'c_pmiclima', name: 'PAULO MICHEL DE LIMA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'pmiclima', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=PAULO+MICHEL' },
  { id: 'c_pauandrade', name: 'PAULO ROBERTO DE ANDRADE', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'pauandrade', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=PAULO+ROBERTO' },
  { id: 'c_pesanto', name: 'PEDRO HENRIQUE LIMA DO ESPIRITO SANTO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'pesanto', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=PEDRO+HENRIQUE' },
  { id: 'c_pedviana', name: 'PEDRO MALVA VIANA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'pedviana', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=PEDRO+MALVA' },
  { id: 'c_ruafreitas', name: 'RAPHAEL RUAN SOUZA FREITAS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'ruafreitas', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=RAPHAEL+RUAN' },
  { id: 'c_raohaelsviei', name: 'RAPHAEL SILVA VIEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'raohaelsviei', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=RAPHAEL+SILVA' },
  { id: 'c_rsabdias', name: 'RAUL SILVA ABDIAS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'rsabdias', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=RAUL+SILVA' },
  { id: 'c_resanto', name: 'REGIVANE PEREIRA DO ESPIRITO SANTO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'resanto', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=REGIVANE+PEREIRA' },
  { id: 'c_renanoli', name: 'RENAN DA SILVA OLIVEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'renanoli', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=RENAN+DA' },
  { id: 'c_renanololive', name: 'RENAN OLIVEIRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'renanololive', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=RENAN+OLIVEIRA' },
  { id: 'c_rsmatos', name: 'RENAN SOUZA MATOS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'rsmatos', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=RENAN+SOUZA' },
  { id: 'c_rendaniel', name: 'RENATO DANIEL DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'rendaniel', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=RENATO+DANIEL' },
  { id: 'c_rogeriocsilv', name: 'ROGERIO CARDOSO DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'rogeriocsilv', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=ROGERIO+CARDOSO' },
  { id: 'c_rubeda', name: 'RUTE CRISTINA UBEDA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'rubeda', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=RUTE+CRISTINA' },
  { id: 'c_samasouza', name: 'SAMARA PEREIRA DE SOUZA', role: 'COLABORADOR', status: 'AFASTADO INSS', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'samasouza', emb: 'VENCIDO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=SAMARA+PEREIRA' },
  { id: 'c_sikeda', name: 'SAYURI IKEDA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'sikeda', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=SAYURI+IKEDA' },
  { id: 'c_sddutra', name: 'SOPHIA DE SOUZA SILVA DUTRA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'sddutra', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=SOPHIA+DE' },
  { id: 'c_stnunes', name: 'STEFFANE NUNES DOS SANTOS', role: 'COLABORADOR', status: 'LIC. MATERNIDADE', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'stnunes', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=STEFFANE+NUNES' },
  { id: 'c_tacandido', name: 'TAIS LIMA CANDIDO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'tacandido', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=TAIS+LIMA' },
  { id: 'c_tambarbosa', name: 'TAMIRES TELES BARBOSA TEODORO', role: 'COLABORADOR', status: 'AFASTADO INSS', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'tambarbosa', emb: 'TREINADO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=TAMIRES+TELES' },
  { id: 'c_tpreto', name: 'TATIANE DA ROCHA FERREIRA PRETO', role: 'COLABORADOR', status: 'AFASTADO INSS', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'tpreto', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=TATIANE+DA' },
  { id: 'c_tmnonato', name: 'THIAGO MAGALHAES NONATO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'tmnonato', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=THIAGO+MAGALHAES' },
  { id: 'c_upacheco', name: 'ULISSES FREITAS PACHECO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'upacheco', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=ULISSES+FREITAS' },
  { id: 'c_valedoliveir', name: 'VALERIA CARDOSO DE OLIVEIRA', role: 'COLABORADOR', status: 'FÉRIAS', turma: 'AA', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'valedoliveir', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=VALERIA+CARDOSO' },
  { id: 'c_vsbarros', name: 'VANDA ARAUJO DOS SANTOS BARROS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'vsbarros', emb: 'VENCIDO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=VANDA+ARAUJO' },
  { id: 'c_viccamargo', name: 'VICTOR DE LARA CAMPOS CAMARGO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'viccamargo', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=VICTOR+DE' },
  { id: 'c_victorhugo', name: 'VICTOR HUGO DANTAS DE AQUINO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'victorhugo', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=VICTOR+HUGO' },
  { id: 'c_vcoscardoso', name: 'VITOR COSSOLIN CARDOSO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'LUCAS LOPES DA SILVA', gestorId: 'g3', username: 'vcoscardoso', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=VITOR+COSSOLIN' },
  { id: 'c_vdpinheiro', name: 'VITOR DOS ANJOS PINHEIRO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'JHONATAN ARIEL LOURENCON DA SILVA', gestorId: 'g4', username: 'vdpinheiro', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=VITOR+DOS' },
  { id: 'c_wwmmacolin', name: 'WALIFY MACOLIN DA SILVA', role: 'COLABORADOR', status: 'ATIVO', turma: 'AA', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'wwmmacolin', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=WALIFY+MACOLIN' },
  { id: 'c_webribeiro', name: 'WEBERSON SANTOS RIBEIRO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AD', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'webribeiro', emb: 'TREINADO', pat: 'SEM TREINAMENTO', photo: 'https://ui-avatars.com/api/?name=WEBERSON+SANTOS' },
  { id: 'c_wmaraujo', name: 'WELLINGTON MARQUES ARAUJO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AC', gestor: 'THIAGO DA SILVA AMI', gestorId: 'g5', username: 'wmaraujo', emb: 'VENCIDO', pat: 'VENCIDO', photo: 'https://ui-avatars.com/api/?name=WELLINGTON+MARQUES' },
  { id: 'c_wmruas', name: 'WILIANE ENEIDA MARAN RUAS', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'GABRIEL AMORIM DE SOUZA', gestorId: 'g2', username: 'wmruas', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=WILIANE+ENEIDA' },
  { id: 'c_ycharles', name: 'YURI CHARLES OLIVEIRA GERONIMO', role: 'COLABORADOR', status: 'ATIVO', turma: 'AB', gestor: 'MICHAEL DAVID DE OLIVEIRA SILVA', gestorId: 'g1', username: 'ycharles', emb: 'TREINADO', pat: 'TREINADO', photo: 'https://ui-avatars.com/api/?name=YURI+CHARLES' },
];

// FIX: vínculo de gestor por ID, não por nome (renomear/promover não quebra a hierarquia)
const GESTOR_ID_MAP = {
  'MICHAEL DAVID DE OLIVEIRA SILVA': 'g1', 'GABRIEL AMORIM DE SOUZA': 'g2',
  'LUCAS LOPES DA SILVA': 'g3', 'JHONATAN ARIEL LOURENCON DA SILVA': 'g4',
  'THIAGO DA SILVA AMI': 'g5', 'TIAGO DORETTO DE JESUS': 'g6', 'IGOR HENRIQUE DO NASCIMENTO': 'g7'
};
INITIAL_USERS.forEach(u => { if (u.gestor && GESTOR_ID_MAP[u.gestor]) u.gestorId = GESTOR_ID_MAP[u.gestor]; });
const getGestorName = (users, id) => users.find(u => u.id === id)?.name || 'Mestre';

const AREAS = ['PATOLADA', 'BP(V4)', 'OUT', 'IN CORES', 'DOCAS IN', 'PUXADA MANGA', 'SORTER', 'MAQUINA'];
const QR_AREAS = AREAS.filter(a => a !== 'MAQUINA'); // MAQUINA não possui QR Code
const ROLES = ['COLABORADOR', 'OPLOG2', 'OPLOG3', 'GESTOR', 'MASTER'];

const getTimeStr = () => new Date().toLocaleTimeString('pt-BR', { hour12: false });
const getDateStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };

// Motor da Escala (folgas reais)
// ESCALA REAL DE FOLGAS (ciclo de 28 dias, ref. 01/08/2026). Posicoes do ciclo em que a turma FOLGA.
// Fonte: calendarios oficiais de folga 2026 (Planejamento Inbound) das turmas AA, AB, AC, AD.
const FOLGA_CICLO_28 = {"AA": [2, 3, 9, 15, 20, 21, 25, 26], "AB": [0, 4, 5, 9, 10, 16, 22, 27], "AC": [1, 6, 7, 11, 12, 16, 17, 23], "AD": [2, 8, 13, 14, 18, 19, 23, 24]};
const isWorkingDay = (turma, dateString) => {
  const t = String(turma || '').toUpperCase().replace(/[^ABCD]/g, '');
  const key = t ? 'A' + t[t.length - 1] : null;
  const folgas = key && FOLGA_CICLO_28[key];
  if (!folgas) return true;
  const [y, m, d] = String(dateString).slice(0, 10).split('-').map(Number);
  const dias = Math.round((Date.UTC(y, m - 1, d) - Date.UTC(2026, 7, 1)) / 86400000);
  const pos = ((dias % 28) + 28) % 28;
  return !folgas.includes(pos);
};

export default function App() {
  // Navigation & Auth
  const [view, setView] = useState('home'); // home, login, pwd_change, qrcodes, checkin, dashboard
  const [currentUser, setCurrentUser] = useState(null);
  
  // UI States
  const [toast, setToast] = useState(null); // { message, type }
  
  // DB States
  const [users, setUsers] = useState(INITIAL_USERS);
  const [logs, setLogs] = useState([]);
  const [ops2Assignments, setOps2Assignments] = useState({}); // { [op2Id]: 'AREA' }
  const [incidents, setIncidents] = useState([]); // Histórico Ociosidade/Comportamento
  const [sosRequests, setSosRequests] = useState([]); // SOS Saturação
  const [areaReports, setAreaReports] = useState([]); // Review de Área exigido pelo Ops 3
  const [pwdRequests, setPwdRequests] = useState([]); // Recuperação de senha
  const [sinergias, setSinergias] = useState([]); // Empréstimo entre áreas
  const [qrForms, setQrForms] = useState({}); // Links do Forms para QR Codes
  const [patoladaHistory, setPatoladaHistory] = useState({}); // Contador da Patolada
  const [lunchBreaks, setLunchBreaks] = useState({}); // { empId: { start, end } }
  const [lunchCoverage, setLunchCoverage] = useState({}); // { [area]: op2Id } cobertura na janta
  const [dotSchedule, setDotSchedule] = useState(null); // Hora a hora do DOT: { date, slots: { '17': op2Id } }
  const [dotReports, setDotReports] = useState([]); // Preenchimentos do hora a hora
  const [extraOps, setExtraOps] = useState({}); // Ops 2 de folga marcados como EXTRA pelo Ops 3

  // ===== PERSISTÊNCIA NA NUVEM (banco de dados Base44) =====
  const [hydrated, setHydrated] = useState(false);
  const [syncStatus, setSyncStatus] = useState('sincronizando'); // sincronizando | salvando | salvo | erro
  const [sheetUrl, setSheetUrl] = useState(null); // planilha oficial do Google Sheets
  const lastPushedRef = useRef(''); // evita salvar na nuvem o que já está lá

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const r = await fetch('/functions/erpState', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'get' }) });
        const d = await r.json();
        if (alive && d.ok && d.payload) {
          const s = JSON.parse(d.payload);
          if (s && Array.isArray(s.users) && s.users.length) {
            setUsers(s.users);
            setLogs(s.logs || []);
            setOps2Assignments(s.ops2Assignments || {});
            setIncidents(s.incidents || []);
            setSosRequests(s.sosRequests || []);
            setAreaReports(s.areaReports || []);
            setPwdRequests(s.pwdRequests || []);
            setSinergias(s.sinergias || []);
            setQrForms(s.qrForms || {});
            setPatoladaHistory(s.patoladaHistory || {});
            setLunchBreaks(s.lunchBreaks || {});
            setLunchCoverage(s.lunchCoverage || {});
            setDotSchedule(s.dotSchedule || null);
            setDotReports(s.dotReports || []);
            setExtraOps(s.extraOps || {});
          }
        }
        if (alive) setSyncStatus('salvo');
      } catch (e) {
        if (alive) setSyncStatus('erro');
      } finally {
        if (alive) setHydrated(true);
      }
    })();
    return () => { alive = false; };
  }, []);

  // Busca o link da planilha oficial do Google Sheets
  useEffect(() => {
    if (!hydrated) return;
    (async () => {
      try {
        const r = await fetch('/functions/erpSheets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'status' }) });
        const d = await r.json();
        if (d.ok && d.url) setSheetUrl(d.url);
      } catch (e) { /* offline */ }
    })();
  }, [hydrated]);

  // Salva o estado no banco (com debounce) sempre que algo muda
  useEffect(() => {
    if (!hydrated) return;
    setSyncStatus(st => (st === 'erro' ? st : 'salvando'));
    const t = setTimeout(async () => {
      try {
        const payload = JSON.stringify({ users, logs, ops2Assignments, incidents, sosRequests, areaReports, pwdRequests, sinergias, qrForms, patoladaHistory, lunchBreaks, lunchCoverage, dotSchedule, dotReports, extraOps });
        if (lastPushedRef.current === payload) { setSyncStatus('salvo'); return; }
        lastPushedRef.current = payload;
        const r = await fetch('/functions/erpState', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'save', payload }) });
        const d = await r.json();
        setSyncStatus(d.ok ? 'salvo' : 'erro');
      } catch (e) {
        setSyncStatus('erro');
      }
    }, 700);
    return () => clearTimeout(t);
  }, [hydrated, users, logs, ops2Assignments, incidents, sosRequests, areaReports, pwdRequests, sinergias, qrForms, patoladaHistory, lunchBreaks, lunchCoverage, dotSchedule, dotReports, extraOps]);

  // SYNC: recarrega da nuvem a cada 30s para ver pontos de QR, exigências e
  // delegações que chegaram depois de o painel ter aberto.
  useEffect(() => {
    if (!hydrated) return;
    const refresh = async () => {
      try {
        const r = await fetch('/functions/erpState', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'get' }) });
        const d = await r.json();
        if (d.ok && d.payload) {
          const s = JSON.parse(d.payload);
          if (s && Array.isArray(s.users)) {
            setUsers(s.users || []);
            setLogs(s.logs || []);
            setOps2Assignments(s.ops2Assignments || {});
            setIncidents(s.incidents || []);
            setSosRequests(s.sosRequests || []);
            setAreaReports(s.areaReports || []);
            setPwdRequests(s.pwdRequests || []);
            setSinergias(s.sinergias || []);
            setLunchBreaks(s.lunchBreaks || {});
            setLunchCoverage(s.lunchCoverage || {});
            setDotSchedule(s.dotSchedule || null);
            setDotReports(s.dotReports || []);
            setExtraOps(s.extraOps || {});
            setSyncStatus('salvo');
          }
        }
      } catch (e) { /* mantém o estado local; o próximo ciclo tenta de novo */ }
    };
    const t = setInterval(refresh, 30000);
    return () => clearInterval(t);
  }, [hydrated]);

  const todayStr = getDateStr();

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Algoritmo Automático da Patolada (Roda 1x ao dia)
  useEffect(() => {
    if (patoladaHistory._lastRun === todayStr) return; // FIX: já rodou hoje
    const todayLogs = logs.filter(l => l.date === todayStr && l.area === 'PATOLADA');
    if (todayLogs.length > 0) return; 
    
    let availableEmps = users.filter(u => u.role === 'COLABORADOR' && u.status === 'ATIVO' && isWorkingDay(u.turma, todayStr));
    availableEmps.sort((a, b) => (patoladaHistory[a.id] || 0) - (patoladaHistory[b.id] || 0));
    const selected = availableEmps.filter(emp => (patoladaHistory[emp.id] || 0) < 3).slice(0, 20);
    
    const newHistory = { ...patoladaHistory };
    selected.forEach(emp => { newHistory[emp.id] = (newHistory[emp.id] || 0) + 1; });
    newHistory._lastRun = todayStr; // FIX: roda 1x por dia, sem inflar o contador
    setPatoladaHistory(newHistory);
  }, [logs, users, patoladaHistory, todayStr]);

  // Envia o relatório do dia direto para a planilha do Google Sheets
  const exportarSheets = () => {
    const team = currentUser.role === 'MASTER'
      ? users.filter(u => u.role === 'COLABORADOR')
      : users.filter(u => u.gestorId === currentUser.id && u.role === 'COLABORADOR');
    const rows = team.map(emp => {
      const log = logs.find(l => l.empId === emp.id && l.date === todayStr);
      const op2Id = Object.keys(ops2Assignments).find(k => ops2Assignments[k] === (log?.area || emp.area));
      const op2Name = users.find(u => u.id === op2Id)?.name || '';
      const isWorking = isWorkingDay(emp.turma, todayStr);
      const status = log ? log.status : (isWorking ? 'FALTA' : 'FOLGA');
      return [emp.name, emp.turma || '', emp.status || '', log?.area || emp.area || '', status, log?.time || '', op2Name, emp.emb || '', emp.pat || ''];
    });
    const scope = currentUser.role === 'MASTER' ? 'master' : 'gestor:' + currentUser.id;
    showToast('Enviando relatório pro Google Sheets...', 'info');
    fetch('/functions/erpSheets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'request', rows, title: 'Relatório ERP - ' + todayStr, scope, requestedBy: currentUser.name, exportDate: todayStr }) })
      .then(r => r.json())
      .then(d => {
        if (!d.ok || !d.id) return showToast('Falha ao enviar o pedido.', 'error');
        const id = d.id;
        let tries = 0;
        const iv = setInterval(async () => {
          tries++;
          try {
            const r2 = await fetch('/functions/erpSheets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'status', id }) });
            const d2 = await r2.json();
            if (d2.status === 'done') { clearInterval(iv); setSheetUrl(d2.url); showToast('Planilha do Google atualizada!', 'success'); }
            else if (d2.status === 'error') { clearInterval(iv); showToast('Falha ao gravar na planilha.', 'error'); }
          } catch (e) { /* tenta de novo */ }
          if (tries > 24) clearInterval(iv);
        }, 5000);
      })
      .catch(() => showToast('Sem conexão com o servidor.', 'error'));
  };

  // Exporta o relatório do dia em CSV (abre direto no Google Sheets ou Excel)
  const exportarRelatorioCSV = () => {
    const team = currentUser.role === 'MASTER'
      ? users.filter(u => u.role === 'COLABORADOR')
      : users.filter(u => u.gestorId === currentUser.id && u.role === 'COLABORADOR');
    const linhas = [['NOME', 'TURMA', 'STATUS CADASTRO', 'AREA HOJE', 'STATUS HOJE', 'HORA', 'OPS 2 RESPONSAVEL', 'EMBARCADA', 'PATOLADA']];
    team.forEach(emp => {
      const log = logs.find(l => l.empId === emp.id && l.date === todayStr);
      const op2Id = Object.keys(ops2Assignments).find(k => ops2Assignments[k] === (log?.area || emp.area));
      const op2Name = users.find(u => u.id === op2Id)?.name || '';
      const isWorking = isWorkingDay(emp.turma, todayStr);
      const status = log ? log.status : (isWorking ? 'FALTA' : 'FOLGA');
      linhas.push([emp.name, emp.turma || '', emp.status || '', log?.area || emp.area || '', status, log?.time || '', op2Name, emp.emb || '', emp.pat || '']);
    });
    const csv = '\ufeff' + linhas.map(l => l.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-erp-${todayStr}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("Relatório CSV gerado! Importe no Google Sheets ou Excel.", "success");
  };

  const db = {
    users, setUsers, logs, setLogs, ops2Assignments, setOps2Assignments,
    incidents, setIncidents, sosRequests, setSosRequests, areaReports, setAreaReports, 
    pwdRequests, setPwdRequests, sinergias, setSinergias, qrForms, setQrForms, lunchBreaks, setLunchBreaks, lunchCoverage, setLunchCoverage, dotSchedule, setDotSchedule, dotReports, setDotReports, extraOps, setExtraOps,
    todayStr, showToast, syncCurrentUser: setCurrentUser, exportarRelatorioCSV, exportarSheets, sheetUrl
  };

  const handleLogin = (username, password) => {
    const user = users.find(u => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password && u.role !== 'COLABORADOR');
    if (user) { 
      setCurrentUser(user);
      if(user.mustChangePwd) setView('pwd_change');
      else setView('dashboard'); 
    }
    else showToast("Credenciais inválidas ou usuário inexistente!", "error");
  };

  const handleLogout = () => { setCurrentUser(null); setView('home'); showToast("Sessão encerrada.", "success"); };

  // QR DE PONTO: link ?ponto=AREA abre a tela de registro direto do colaborador (sem login)
  const [qrArea, setQrArea] = useState(null);
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get('ponto');
    if (p && p.trim()) setQrArea(p.trim().toUpperCase());
  }, []);
  if (qrArea) return <SelfCheckinScreen area={qrArea} />;

  if (!hydrated) {
    return (
      <div className="h-screen bg-slate-900 flex flex-col items-center justify-center text-white gap-4">
        <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold">Sincronizando com a nuvem...</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden text-slate-800 font-sans">

      {/* Selo de sincronização com a nuvem */}
      <div className={`fixed bottom-3 right-3 z-[90] px-3 py-1.5 rounded-full text-[11px] font-bold shadow-lg flex items-center gap-1.5
        ${syncStatus === 'salvo' ? 'bg-emerald-600 text-white' : syncStatus === 'salvando' ? 'bg-amber-500 text-white' : syncStatus === 'erro' ? 'bg-red-600 text-white' : 'bg-slate-500 text-white'}`}>
        {syncStatus === 'salvo' ? '☁ Dados salvos na nuvem' : syncStatus === 'salvando' ? '⏳ Sincronizando...' : syncStatus === 'erro' ? '⚠ Sem conexão (dados locais)' : '⏳ Sincronizando...'}
      </div>
      
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-6 right-6 z-[100] px-6 py-4 rounded-xl shadow-2xl text-white font-bold flex items-center gap-3 animate-slide-in
          ${toast.type === 'error' ? 'bg-red-600' : toast.type === 'success' ? 'bg-green-600' : 'bg-slate-800'}`}>
          {toast.type === 'error' ? <XCircle size={24}/> : toast.type === 'success' ? <CheckCircle size={24}/> : <Bell size={24}/>}
          {toast.message}
        </div>
      )}

      {/* Roteamento Manual */}
      {view === 'home' && <HomePortal setView={setView} />}
      {view === 'checkin' && <CheckinPortal db={db} onBack={() => setView('home')} />}
      {view === 'login' && <LoginPortal onLogin={handleLogin} db={db} onBack={() => setView('home')} />}
      {view === 'qrcodes' && <QRCodePortal db={db} onBack={() => setView('home')} />}
      {view === 'pwd_change' && <FirstAccessPortal currentUser={currentUser} db={db} onComplete={() => setView('dashboard')} />}

      {view === 'dashboard' && currentUser && (
        <>
          <Sidebar currentUser={currentUser} setView={setView} onLogout={handleLogout} />
          <main className="flex-1 overflow-y-auto bg-slate-50 relative">
            <div className="p-8 max-w-7xl mx-auto">
              <Header currentUser={currentUser} db={db} />
              {currentUser.role === 'MASTER' && <MasterView db={db} />}
              {currentUser.role === 'GESTOR' && <GestorView currentUser={currentUser} db={db} />}
              {currentUser.role === 'OPLOG3' && <Ops3View currentUser={currentUser} db={db} />}
              {currentUser.role === 'OPLOG2' && <Ops2View currentUser={currentUser} db={db} />}
            </div>
          </main>
        </>
      )}
    </div>
  );
}

// ==========================================
// COMPONENTES GLOBAIS
// ==========================================

function HomePortal({ setView }) {
  return (
    <div className="w-full flex items-center justify-center bg-slate-900 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
      <div className="bg-white p-12 rounded-3xl shadow-2xl max-w-lg w-full text-center">
        <div className="w-20 h-20 bg-blue-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/30">
          <Map size={40} />
        </div>
        <h1 className="text-3xl font-extrabold text-slate-800 mb-2">ERP Logístico</h1>
        <p className="text-slate-500 mb-10">Gestão Operacional, Ponto e Produtividade</p>
        <p className="text-[10px] font-black text-blue-500 mb-2 tracking-widest">VERSAO 1.13 - 15/10 SOS + DEVOLVER SINERGIA</p>
        
        <div className="space-y-4">
          <button onClick={() => setView('checkin')} className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 p-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-colors border border-slate-200">
            <QrCode size={20}/> Simulador de Check-in (Colaborador)
          </button>
          <button onClick={() => setView('login')} className="w-full bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-colors shadow-lg shadow-blue-500/20">
            <Lock size={20}/> Acesso Gestão / OPLOG
          </button>
          <button onClick={() => setView('qrcodes')} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-colors shadow-lg shadow-emerald-500/20">
            <Printer size={20}/> Gerador de QR Codes
          </button>
        </div>
      </div>
    </div>
  );
}

function Sidebar({ currentUser, setView, onLogout }) {
  return (
    <div className="w-72 bg-slate-900 text-slate-300 flex flex-col shadow-2xl z-10 border-r border-slate-800">
      <div className="p-8 bg-slate-950 text-center border-b border-slate-800">
        <img src={currentUser.photo} alt="Profile" className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-blue-500 object-cover shadow-lg" />
        <h2 className="font-bold text-white text-lg truncate leading-tight">{currentUser.name}</h2>
        <p className="text-xs text-slate-400 mt-1">@{currentUser.username}</p>
        <span className="text-[10px] uppercase tracking-widest bg-blue-600 text-white px-3 py-1 rounded-full mt-3 inline-block font-bold">{currentUser.role}</span>
      </div>
      <nav className="flex-1 p-6 space-y-3">
        <button onClick={() => setView('dashboard')} className="w-full flex items-center gap-3 p-4 rounded-xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 transition-colors font-bold">
          <Map size={20}/> Painel de Controle
        </button>
        <button className="w-full flex items-center gap-3 p-4 rounded-xl hover:bg-slate-800 transition-colors font-semibold">
          <User size={20}/> Meu Perfil
        </button>
      </nav>
      <div className="p-6 border-t border-slate-800">
        <button onClick={onLogout} className="w-full flex items-center justify-center gap-2 p-4 bg-slate-800 hover:bg-red-600 text-white rounded-xl font-bold transition-all">
          <LogOut size={20}/> Sair do Sistema
        </button>
      </div>
    </div>
  );
}

function Header({ currentUser, db }) {
  const pendingPwd = db.pwdRequests.filter(r => r.status === 'PENDING').length;
  const sosActive = db.sosRequests.filter(r => r.status === 'OPEN').length;

  return (
    <div className="flex justify-between items-center mb-8 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Painel Operacional</h1>
        <p className="text-slate-500 text-sm mt-1">{new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>
      <div className="flex items-center gap-3">
        {currentUser.role === 'MASTER' && pendingPwd > 0 && (
          <span className="flex items-center gap-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-full text-sm font-bold border border-amber-200 shadow-sm">
            <Lock size={16}/> {pendingPwd} Senha(s) Pendente(s)
          </span>
        )}
        {sosActive > 0 && (
          <span className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg shadow-red-500/30 animate-pulse">
            <AlertTriangle size={16}/> S.O.S na Rede
          </span>
        )}
      </div>
    </div>
  );
}

function LoginPortal({ onLogin, db, onBack }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isRecover, setIsRecover] = useState(false);
  const [newPwd, setNewPwd] = useState('');

  const handleRecover = (e) => {
    e.preventDefault();
    // FIX: valida se o usuário existe antes de mandar pro Mestre
    const user = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());
    if (!user) return db.showToast("Usuário não encontrado. Confirme com o seu gestor.", "error");
    if (!newPwd.trim() || newPwd.trim().length < 3) return db.showToast("Digite uma senha válida (mín. 3 caracteres).", "error");
    db.setPwdRequests([...db.pwdRequests, { id: Date.now(), username: user.username, newPassword: newPwd.trim(), status: 'PENDING' }]);
    db.showToast("Solicitação enviada ao Perfil Mestre.", "success");
    setIsRecover(false);
  };

  return (
    <div className="flex items-center justify-center h-screen bg-slate-900 w-full relative">
      <button onClick={onBack} className="absolute top-6 left-6 text-slate-400 hover:text-white font-bold flex items-center gap-2"><ArrowRight className="rotate-180"/> Voltar</button>
      
      <div className="bg-white p-10 rounded-3xl shadow-2xl w-full max-w-md border border-slate-200">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-slate-100 text-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-inner">
            <Shield size={32} />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-800">{isRecover ? 'Recuperação de Conta' : 'Acesso Restrito'}</h2>
          <p className="text-slate-500 text-sm mt-1">Apenas cargos de Gestão e OPLOG</p>
        </div>

        {!isRecover ? (
          <form onSubmit={e => { e.preventDefault(); onLogin(username, password); }} className="space-y-5">
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Usuário</label>
              <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all" required />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Senha</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all" required />
            </div>
            <button type="submit" className="w-full bg-slate-800 hover:bg-slate-900 text-white p-4 rounded-xl font-bold text-lg transition-colors shadow-lg">Entrar</button>
            <p className="text-center text-sm font-semibold text-slate-500 cursor-pointer hover:text-slate-800 transition-colors" onClick={() => setIsRecover(true)}>Esqueci minha senha/usuário</p>
          </form>
        ) : (
          <form onSubmit={handleRecover} className="space-y-5">
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Seu Usuário Atual</label>
              <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 outline-none" required />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Nova Senha Desejada</label>
              <input type="text" value={newPwd} onChange={e => setNewPwd(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 outline-none" required />
            </div>
            <button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white p-4 rounded-xl font-bold text-lg shadow-lg">Solicitar ao Mestre</button>
            <p className="text-center text-sm font-semibold text-slate-500 cursor-pointer hover:text-slate-800 transition-colors" onClick={() => setIsRecover(false)}>Voltar ao Login</p>
          </form>
        )}
      </div>
    </div>
  );
}

function FirstAccessPortal({ currentUser, db, onComplete }) {
  const [newUsername, setNewUsername] = useState(currentUser.username);
  const [newPassword, setNewPassword] = useState('');

  const handleSave = (e) => {
    e.preventDefault();
    if(newPassword.length < 3) return db.showToast("Senha muito curta.", "error");
    if(newPassword === '123') return db.showToast("Você não pode usar a senha padrão.", "error");
    const finalUsername = newUsername.trim();
    // FIX: impede dois usuários com o mesmo login
    const dup = db.users.find(u => u.id !== currentUser.id && u.username.toLowerCase() === finalUsername.toLowerCase());
    if (dup) return db.showToast("Este nome de usuário já está em uso.", "error");
    
    db.setUsers(db.users.map(u => u.id === currentUser.id ? { ...u, username: finalUsername, password: newPassword, mustChangePwd: false } : u));
    db.syncCurrentUser({ ...currentUser, username: finalUsername, password: newPassword, mustChangePwd: false }); // FIX: sidebar mostrava o login antigo
    db.showToast("Credenciais atualizadas com sucesso! Bem-vindo.", "success");
    onComplete();
  };

  return (
    <div className="flex items-center justify-center h-screen bg-slate-900 w-full relative">
      <form onSubmit={handleSave} className="bg-white p-10 rounded-3xl shadow-2xl w-full max-w-md space-y-6">
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner"><Lock size={36}/></div>
          <h2 className="text-3xl font-extrabold text-slate-800">Primeiro Acesso</h2>
          <p className="text-slate-600 text-sm mt-2 font-medium bg-slate-50 p-3 rounded-lg border border-slate-100">
            Olá, <b>{currentUser.name}</b>. Por segurança, é obrigatório alterar seu usuário e senha padrão antes de acessar o sistema.
          </p>
        </div>
        <div>
          <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Novo Nome de Usuário</label>
          <input type="text" value={newUsername} onChange={e=>setNewUsername(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 outline-none focus:ring-2 focus:ring-amber-500" required />
        </div>
        <div>
          <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Sua Nova Senha</label>
          <input type="password" placeholder="Digite uma senha forte" value={newPassword} onChange={e=>setNewPassword(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 outline-none focus:ring-2 focus:ring-amber-500" required />
        </div>
        <button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white p-4 rounded-xl font-bold text-lg shadow-lg transition-colors">Salvar e Acessar</button>
      </form>
    </div>
  );
}

function CheckinPortal({ db, onBack }) {
  const [username, setUsername] = useState('');
  const [area, setArea] = useState('');
  const [gestor, setGestor] = useState('');
  const [lembrou, setLembrou] = useState(false);

  // Ao digitar o usuário, busca o que a nuvem já lembra (área e gestor)
  const handleUsername = (val) => {
    setUsername(val);
    setLembrou(false);
    const emp = db.users.find(u => u.username.toLowerCase() === val.trim().toLowerCase() && (u.role === 'COLABORADOR' || u.role === 'OPLOG2'));
    if (emp && (emp.area || emp.gestor)) {
      if (emp.area) setArea(emp.area);
      if (emp.gestor) setGestor(emp.gestor);
      setLembrou(true);
    }
  };

  const gestores = [...new Set(db.users.filter(u => u.role === 'GESTOR' || u.role === 'MASTER').map(u => u.name))].sort();

  const handleCheckin = (e) => {
    e.preventDefault();
    const emp = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase() && (u.role === 'COLABORADOR' || u.role === 'OPLOG2'));
    if(!emp) return db.showToast("Usuário não encontrado.", "error");
    if(emp.status !== 'ATIVO') return db.showToast(`Colaborador está como "${emp.status}". Procure o seu TL.`, "error");
    if(!area) return db.showToast("Selecione a área.", "error");
    if(!gestor) return db.showToast("Selecione o gestor.", "error");
    // FIX: um ponto por dia, evita registro em duplicidade
    if(db.logs.some(l => l.empId === emp.id && l.date === db.todayStr)) return db.showToast("Ponto de hoje já registrado.", "error");

    const isWorkDay = isWorkingDay(emp.turma, db.todayStr);
    const status = isWorkDay ? 'PRESENTE' : 'HORA EXTRA';

    // FIX: grava a área atual no cadastro, senão o Ops 2 e o Gestor não veem o colaborador em lugar nenhum
    db.setUsers(db.users.map(u => u.id === emp.id ? { ...u, area, gestor, areaAt: Date.now() } : u));
    db.setLogs([{ id: Date.now(), empId: emp.id, name: emp.name, gestor, area, date: db.todayStr, time: getTimeStr(), status, source: 'QR_CODE' }, ...db.logs]);
    db.showToast(`Ponto registrado com sucesso! (${status})`, "success");
    setUsername(''); setArea(''); setGestor(''); setLembrou(false);
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-slate-100 p-6 relative w-full">
      <button onClick={onBack} className="absolute top-6 left-6 font-bold text-slate-500 flex items-center gap-2 hover:text-slate-800"><ArrowRight className="rotate-180"/> Voltar</button>
      
      <div className="bg-white p-10 rounded-3xl shadow-xl w-full max-w-md border border-slate-200">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4"><QrCode size={32}/></div>
          <h2 className="text-2xl font-extrabold text-slate-800">Check-in Operacional</h2>
          <p className="text-sm text-slate-500 mt-2">Simulação da tela do colaborador pelo celular.</p>
        </div>
        <form onSubmit={handleCheckin} className="space-y-5">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Usuário</label>
            <input type="text" placeholder="Ex: alanbsantos" value={username} onChange={e=>handleUsername(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white outline-none" required/>
            {lembrou && <p className="text-xs font-bold text-emerald-600 mt-1">Área e gestor lembrados da nuvem. Só confirmar!</p>}
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Área de Atuação Hoje</label>
            <select value={area} onChange={e=>setArea(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white outline-none font-semibold text-slate-700" required>
              <option value="">Selecione...</option>
              {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Gestor Imediato</label>
            <select value={gestor} onChange={e=>setGestor(e.target.value)} className="w-full p-4 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white outline-none font-semibold text-slate-700" required>
              <option value="">Selecione...</option>
              {gestores.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white p-4 rounded-xl font-bold text-lg shadow-lg">Confirmar Presença</button>
        </form>
      </div>
    </div>
  );
}

// ===== TELA DE PONTO POR QR CODE (?ponto=AREA) =====
// O colaborador bipa o QR, a página abre com a área pré-preenchida,
// digita LDAP (ou nome completo) e o ponto cai direto na nuvem.
function SelfCheckinScreen({ area }) {
  const [username, setUsername] = useState('');
  const [gestor, setGestor] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null); // { ok:true, name, time, area, gestor } | { ok:false, error }

  const submit = async () => {
    if (!username.trim()) { setResult({ ok: false, error: 'Digite seu usuário (LDAP) ou nome completo' }); return; }
    setLoading(true); setResult(null);
    try {
      const r = await fetch('/functions/erpCheckin', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), area, gestor: gestor.trim() }) });
      setResult(await r.json());
    } catch (e) {
      setResult({ ok: false, error: 'Sem conexão. Verifique o sinal e tente de novo.' });
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-slate-900 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] flex flex-col items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md text-center">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg shadow-blue-500/30"><Clock size={36} className="text-white"/></div>
        <h1 className="text-2xl font-extrabold text-slate-800 tracking-wide">REGISTRO DE PONTO</h1>
        <p className="text-blue-600 font-black text-4xl my-4 tracking-wider">{area}</p>
        {!result?.ok ? (
          <div>
            <input autoFocus value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Seu usuário (LDAP)"
              className="w-full text-center text-lg font-bold p-4 border-2 border-slate-200 rounded-xl mb-3 focus:border-blue-500 outline-none"/>
            <input value={gestor} onChange={(e) => setGestor(e.target.value)} placeholder="Nome do seu TL (opcional)"
              className="w-full text-center text-lg font-bold p-4 border-2 border-slate-200 rounded-xl mb-5 focus:border-blue-500 outline-none"/>
            <button onClick={submit} disabled={loading}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-xl font-black p-5 rounded-2xl shadow-lg disabled:opacity-50 transition-colors">
              {loading ? 'REGISTRANDO...' : 'BATER PONTO'}
            </button>
            {result?.error && <p className="text-red-600 font-bold mt-4">{result.error}</p>}
          </div>
        ) : (
          <div>
            <CheckCircle size={72} className="text-green-500 mx-auto my-4"/>
            <p className="text-xl font-black text-slate-800">{result.name}</p>
            <p className="text-lg font-bold text-slate-600 mt-1">Ponto registrado às {result.time}</p>
            <p className="text-sm font-bold text-blue-600 mt-1">Área: {result.area}{result.gestor ? ` | TL: ${result.gestor}` : ''}</p>
            <p className="text-xs text-slate-400 mt-4">Pode fechar esta página. Bom trabalho!</p>
          </div>
        )}
      </div>
    </div>
  );
}

function QRCodePortal({ db, onBack }) {
  const handleSaveLink = (area, link) => {
    db.setQrForms({ ...db.qrForms, [area]: link });
    db.showToast("Link salvo para a área: " + area, "success");
  };

  return (
    <div className="h-screen flex flex-col bg-slate-100">
      <div className="bg-blue-700 text-white p-5 flex justify-between items-center shadow-md print:hidden">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="bg-blue-800 p-2 rounded-xl hover:bg-blue-900 transition-colors"><ArrowRight className="rotate-180"/></button>
          <h1 className="font-extrabold text-xl tracking-wide">Gestão de Check-in (QR Codes de Ponto)</h1>
        </div>
        <button onClick={() => window.print()} className="flex items-center gap-2 bg-white text-blue-700 px-5 py-2.5 rounded-xl font-bold shadow-sm">
          <Printer size={18}/> Imprimir QRs
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-8 print:p-0">
        <div className="max-w-6xl mx-auto space-y-8">
          
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 print:hidden">
            <h2 className="font-extrabold text-2xl text-slate-800 mb-3 flex items-center gap-2"><QrCode/> Instruções</h2>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              Os QR Codes agora apontam para a tela de registro de ponto do próprio sistema (não precisa mais do Google Forms).
              Basta imprimir e colar nas áreas: o colaborador bipa, digita o LDAP e o ponto cai na nuvem na hora — sem script, sem acionador, sem erro de acento.
            </p>
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
              <h3 className="font-bold text-blue-800 mb-2">💡 Como funciona</h3>
              <p className="text-sm text-blue-700">Cada QR abre a página do sistema com a área já preenchida. Aceita o LDAP ou o nome completo. Se ainda tiver um QR antigo do Google Forms impresso, substitua pelo novo desta página.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 print:grid-cols-2 print:gap-10">
            {QR_AREAS.map(area => {
              const url = `https://avataralenda96-hash.github.io/erp-logistico/?ponto=${encodeURIComponent(area)}`;
              // Using free and reliable QR Server API
              const qrImageUrl = url ? `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}` : null;

              return (
                <div key={area} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 flex flex-col items-center print:shadow-none print:border-4 print:border-black print:p-10">
                  <h3 className="font-black text-2xl text-slate-800 mb-6 uppercase tracking-widest">{area}</h3>
                  
                  {qrImageUrl ? (
                    <div className="bg-white p-4 rounded-2xl border-4 border-slate-100 mb-6 shadow-sm">
                      <img src={qrImageUrl} alt={`QR Code ${area}`} className="w-56 h-56" crossOrigin="anonymous"/>
                    </div>
                  ) : (
                    <div className="w-56 h-56 bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl flex items-center justify-center text-slate-400 mb-6 print:hidden">
                      <div className="text-center"><QrCode size={40} className="mx-auto mb-2 opacity-50"/> Sem link</div>
                    </div>
                  )}

                  <div className="w-full space-y-3 print:hidden">
                    {url && (
                      <a href={url} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1 text-blue-600 text-sm font-bold hover:underline">
                        Testar Link <ExternalLink size={14}/>
                      </a>
                    )}
                  </div>
                  
                  <div className="hidden print:block text-center mt-6 text-lg font-bold text-black border-t-2 border-black pt-4 w-full">
                    Aponte a câmera para registrar presença em <br/><span className="text-2xl mt-2 block">{area}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// MASTER VIEW (Super Admin)
// ==========================================
function MasterView({ db }) {
  const [search, setSearch] = useState('');
  
  const handlePromote = (userId, newRole) => {
    db.setUsers(db.users.map(u => u.id === userId ? { ...u, role: newRole, ...(newRole === 'GESTOR' ? { gestor: null, gestorId: null, turma: null } : {}) } : u));
    db.showToast(`Cargo atualizado para ${newRole}`, "success");
  };

  const handlePwdApproval = (reqId, isApproved) => {
    const req = db.pwdRequests.find(r => r.id === reqId);
    if (isApproved) {
      db.setUsers(db.users.map(u => u.username === req.username ? { ...u, password: req.newPassword } : u));
      db.showToast("Senha alterada com sucesso.", "success");
    } else {
      db.showToast("Pedido recusado.", "error");
    }
    db.setPwdRequests(db.pwdRequests.map(r => r.id === reqId ? { ...r, status: isApproved ? 'APPROVED' : 'REJECTED' } : r));
  };

  const filteredUsers = db.users.filter(u => u.name.toLowerCase().includes(search.toLowerCase()) || u.username.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Aprovação de Senhas */}
      {db.pwdRequests.filter(r => r.status === 'PENDING').length > 0 && (
        <div className="bg-white p-8 rounded-3xl shadow-sm border-l-8 border-amber-500">
          <h3 className="font-extrabold text-xl mb-4 text-slate-800 flex items-center gap-2"><Lock className="text-amber-500"/> Autorização de Senhas</h3>
          <div className="space-y-3">
            {db.pwdRequests.filter(r => r.status === 'PENDING').map(req => (
              <div key={req.id} className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-200">
                <span className="text-slate-700 font-medium">O utilizador <b>{req.username}</b>{db.users.find(u => u.username === req.username) ? ` (${db.users.find(u => u.username === req.username).name})` : ''} solicitou alteração de senha.</span>
                <div className="flex gap-2">
                  <button onClick={() => handlePwdApproval(req.id, true)} className="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-xl font-bold shadow-sm">Autorizar</button>
                  <button onClick={() => handlePwdApproval(req.id, false)} className="bg-red-500 hover:bg-red-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-sm">Recusar</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Diretório Global */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h3 className="font-extrabold text-2xl text-slate-800">Diretório Global (Poder Absoluto)</h3>
            <p className="text-slate-500 text-sm mt-1">Gerencie cargos e acompanhe a hierarquia de todos os colaboradores.</p>
          </div>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5"/>
            <input type="text" placeholder="Pesquisar pessoa..." value={search} onChange={e=>setSearch(e.target.value)} className="pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl w-80 focus:bg-white outline-none focus:ring-2 focus:ring-blue-500 font-medium"/>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => db.exportarSheets()} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">📊 Google Sheets</button>
            <button onClick={() => db.exportarRelatorioCSV()} className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">⬇ CSV</button>
            {db.sheetUrl && <a href={db.sheetUrl} target="_blank" rel="noreferrer" className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">🔗 Abrir Planilha</a>}
          </div>
        </div>
        
        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-extrabold border-b border-slate-200 tracking-wider">
              <tr>
                <th className="p-5">Perfil</th>
                <th className="p-5">Cargo (Ação)</th>
                <th className="p-5">Área / Turma</th>
                <th className="p-5">Gestor Imediato</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map(u => (
                <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-5 flex items-center gap-4">
                    <img src={u.photo} className="w-12 h-12 rounded-full border border-slate-200 shadow-sm" alt=""/>
                    <div>
                      <div className="font-bold text-slate-800 text-base">{u.name}</div>
                      <div className="text-xs text-slate-500 font-medium">User: {u.username}</div>
                    </div>
                  </td>
                  <td className="p-5">
                    <select 
                      className={`p-2 border rounded-lg font-bold text-xs outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer
                        ${u.role==='MASTER'?'bg-slate-800 text-white border-slate-800':
                          u.role==='GESTOR'?'bg-blue-100 text-blue-800 border-blue-200':
                          'bg-white text-slate-700 border-slate-300'}`}
                      value={u.role}
                      onChange={(e) => handlePromote(u.id, e.target.value)}
                    >
                      {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </td>
                  <td className="p-5 text-slate-600 font-medium">{u.area || '-'} / <span className="bg-slate-100 px-2 py-1 rounded-md">{u.turma || '-'}</span></td>
                  <td className="p-5 text-slate-600 font-bold">{u.gestor || 'Supremo'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <IncidentsHistory db={db} role="MASTER" />
    </div>
  );
}

// ==========================================
// GESTOR (TL) VIEW
// ==========================================
function GestorView({ currentUser, db }) {
  const myTeam = db.users.filter(u => u.gestorId === currentUser.id && u.role === 'COLABORADOR');
  const [filterArea, setFilterArea] = useState('');
  const [activeModal, setActiveModal] = useState(null); // Sinergia, Transferência, Ponto Manual
  const [modalForm, setModalForm] = useState({});

  const filteredTeam = myTeam.filter(u => filterArea ? u.area === filterArea : true);
  const pendingRequestsToMe = db.sinergias.filter(s => s.toGestorId === currentUser.id && s.status === 'PENDING' && s.date === db.todayStr);

  const handleSinergiaResponse = (reqId, isAccepted) => {
    const req = db.sinergias.find(s => s.id === reqId);
    db.setSinergias(db.sinergias.map(s => s.id === reqId ? { ...s, status: isAccepted ? 'ACCEPTED' : 'REJECTED' } : s));
    // FIX: aceitar a sinergia agora MOVE o colaborador para a área combinada (antes não fazia nada)
    if (isAccepted && req) {
      db.setUsers(db.users.map(u => u.id === req.empId ? { ...u, area: req.toArea, areaAt: Date.now() } : u));
      db.showToast(`Sinergia aceita. ${req.empName} movido para ${req.toArea}.`, "success");
    } else {
      db.showToast("Sinergia recusada.", "error");
    }
  };

  const executeModalAction = () => {
    const { type, empId } = activeModal;
    const emp = db.users.find(u=>u.id===empId);

    if(type !== 'PONTO' && (!modalForm.gestor || !modalForm.area)) 
      return db.showToast("Selecione o gestor e a área de destino.", "error");

    if(type === 'SINERGIA') {
      // FIX: guarda ID e nome do gestor destino (o nome sozinho quebrava se ele fosse renomeado)
      const toGestorObj = db.users.find(u=>u.id===modalForm.gestor);
      db.setSinergias([...db.sinergias, { 
        id: Date.now(), empId, empName: emp.name, fromGestor: currentUser.name, fromGestorId: currentUser.id,
        toGestor: toGestorObj?.name, toGestorId: modalForm.gestor, toArea: modalForm.area, status: 'PENDING', date: db.todayStr 
      }]);
      db.showToast("Pedido de sinergia enviado com sucesso!", "success");
    } else if (type === 'TRANSFERENCIA') {
      const toGestorObj = db.users.find(u=>u.id===modalForm.gestor);
      db.setUsers(db.users.map(u => u.id === empId ? { ...u, gestor: toGestorObj?.name, gestorId: modalForm.gestor, area: modalForm.area, areaAt: Date.now() } : u));
      db.showToast("Transferência definitiva concluída.", "success");
    } else if (type === 'PONTO') {
      const pArea = modalForm.area || emp.area;
      const pGestor = modalForm.gestor || emp.gestor;
      if (!pArea) return db.showToast("Selecione a área em que o colaborador está atuando.", "error");
      db.setUsers(db.users.map(u => u.id === emp.id ? { ...u, area: pArea, gestor: pGestor, areaAt: Date.now() } : u));
      db.setLogs([{ id: Date.now(), empId: emp.id, name: emp.name, gestor: pGestor, area: pArea, date: db.todayStr, time: getTimeStr(), status: 'PRESENTE', source: 'MANUAL' }, ...db.logs]);
      db.showToast(`Ponto manual registrado na área ${pArea}.`, "success");
    }
    setActiveModal(null);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Alertas de Sinergia */}
      {pendingRequestsToMe.length > 0 && (
        <div className="bg-amber-50 p-8 rounded-3xl shadow-sm border border-amber-200">
          <h3 className="font-bold text-amber-800 text-lg mb-4 flex items-center gap-2"><RefreshCw/> Sinergias Recebidas</h3>
          <div className="space-y-3">
            {pendingRequestsToMe.map(req => (
              <div key={req.id} className="flex justify-between items-center bg-white p-4 rounded-xl border border-amber-100 shadow-sm">
                <span className="text-slate-700">O gestor <b>{req.fromGestor}</b> enviou <b>{req.empName}</b> para a área <b>{req.toArea}</b>. Aceita?</span>
                <div className="flex gap-2">
                  <button onClick={() => handleSinergiaResponse(req.id, true)} className="bg-green-600 text-white px-4 py-2 rounded-lg font-bold">Aceitar</button>
                  <button onClick={() => handleSinergiaResponse(req.id, false)} className="bg-red-500 text-white px-4 py-2 rounded-lg font-bold">Recusar</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Gestão da Equipe */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h3 className="font-extrabold text-2xl text-slate-800">Minha Equipe ({myTeam.length})</h3>
            <p className="text-sm text-slate-500 mt-1">Controle de presença, treinamentos e alocação.</p>
          </div>
          <select value={filterArea} onChange={e=>setFilterArea(e.target.value)} className="p-3 border border-slate-300 rounded-xl bg-slate-50 outline-none focus:ring-2 focus:ring-blue-500 font-bold text-slate-700">
            <option value="">Filtro: Todas as Áreas</option>
            {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
          <div className="flex items-center gap-2">
            <button onClick={() => db.exportarSheets()} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">📊 Google Sheets</button>
            <button onClick={() => db.exportarRelatorioCSV()} className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">⬇ CSV</button>
            {db.sheetUrl && <a href={db.sheetUrl} target="_blank" rel="noreferrer" className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-sm rounded-xl shadow-sm flex items-center gap-2">🔗 Abrir Planilha</a>}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredTeam.map(emp => {
            const empLog = db.logs.find(l => l.empId === emp.id && l.date === db.todayStr);
            const op2Names = Object.keys(db.ops2Assignments).filter(k => db.ops2Assignments[k] === emp.area).map(k => db.users.find(u => u.id === k)?.name).filter(Boolean);
            const op2Name = op2Names.length ? op2Names.join(', ') : 'Sem Ops Delegado';
            
            const isWorking = isWorkingDay(emp.turma, db.todayStr);
            const badgeLabel = empLog ? empLog.status : (isWorking ? 'FALTA' : 'FOLGA');
            const badgeColor = badgeLabel === 'PRESENTE' ? 'bg-green-100 text-green-700' : badgeLabel === 'HORA EXTRA' ? 'bg-purple-100 text-purple-700' : badgeLabel === 'FOLGA' ? 'bg-slate-200 text-slate-600' : 'bg-red-100 text-red-700';

            return (
              <div key={emp.id} className="border border-slate-200 p-6 rounded-2xl flex flex-col justify-between hover:shadow-lg transition-shadow bg-slate-50">
                <div>
                  <div className="flex items-center gap-4 mb-4">
                    <img src={emp.photo} className="w-14 h-14 rounded-full border border-slate-300 shadow-sm" alt=""/>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-slate-800 text-base truncate" title={emp.name}>{emp.name}</div>
                      <div className="text-xs font-bold text-slate-500 mt-1">Turma {emp.turma} • {emp.area}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2.5 text-xs text-slate-600 bg-white p-4 rounded-xl border border-slate-100 mb-4">
                    <div className="flex justify-between items-center">
                      <b>Status Hoje:</b> 
                      <span className={`px-2.5 py-1 rounded-md font-black text-[10px] tracking-wide ${badgeColor}`}>
                        {badgeLabel} {empLog && `(${empLog.time})`}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <b>Ops 2 Responsável:</b> <span className="font-semibold text-blue-600 truncate max-w-[120px]">{op2Name}</span>
                    </div>
                    <div className="pt-2 mt-2 border-t border-slate-100 flex justify-between">
                      <span>Embarcada: <b className={emp.emb==='VENCIDO'?'text-red-600':emp.emb==='SEM TREINAMENTO'?'text-amber-600':'text-green-600'}>{emp.emb||'N/A'}</b></span>
                      <span>Patolada: <b className={emp.pat==='VENCIDO'?'text-red-600':emp.pat==='SEM TREINAMENTO'?'text-amber-600':'text-slate-600'}>{emp.pat||'N/A'}</b></span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button onClick={() => { setModalForm({}); setActiveModal({type: 'SINERGIA', empId: emp.id}); }} className="flex-1 bg-blue-100 hover:bg-blue-200 text-blue-800 py-2.5 rounded-xl text-xs font-bold transition-colors">Sinergia</button>
                  <button onClick={() => { setModalForm({}); setActiveModal({type: 'TRANSFERENCIA', empId: emp.id}); }} className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-800 py-2.5 rounded-xl text-xs font-bold transition-colors">Transferir</button>
                  {!empLog && <button onClick={() => { setActiveModal({type: 'PONTO', empId: emp.id}); }} className="flex-1 bg-green-100 hover:bg-green-200 text-green-800 py-2.5 rounded-xl text-xs font-bold transition-colors">Ponto</button>}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <IncidentsHistory db={db} role="GESTOR" gestorId={currentUser.id} />

      {/* Action Modal */}
      {activeModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-[100] animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-sm w-full">
            <h3 className="text-2xl font-extrabold text-slate-800 mb-2">
              {activeModal.type === 'PONTO' ? 'Lançamento Manual' : activeModal.type === 'SINERGIA' ? 'Empréstimo (Sinergia)' : 'Transferência Definitiva'}
            </h3>
            <p className="text-sm text-slate-500 mb-6">
              {activeModal.type === 'PONTO' ? 'Apenas utilize se o QR Code falhar.' : 'Selecione o destino do colaborador.'}
            </p>
            
            {activeModal.type === 'PONTO' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Área de Atuação</label>
                  <select value={modalForm.area ?? (db.users.find(u=>u.id===activeModal.empId)?.area || '')} onChange={e=>setModalForm({...modalForm, area: e.target.value})} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold">
                    <option value="">Selecione...</option>
                    {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Gestor</label>
                  <select value={modalForm.gestor ?? (db.users.find(u=>u.id===activeModal.empId)?.gestor || '')} onChange={e=>setModalForm({...modalForm, gestor: e.target.value})} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold">
                    <option value="">Selecione...</option>
                    {db.users.filter(u=>u.role==='GESTOR'||u.role==='MASTER').map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                  </select>
                </div>
              </div>
            )}
            {activeModal.type !== 'PONTO' && (
              <div className="space-y-4 mb-6">
                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Gestor Destino</label>
                  <select value={modalForm.gestor||''} onChange={e=>setModalForm({...modalForm, gestor: e.target.value})} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold">
                    <option value="">Selecione...</option>
                    {db.users.filter(u=>u.role==='GESTOR' && u.id!==currentUser.id).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Área Destino</label>
                  <select value={modalForm.area||''} onChange={e=>setModalForm({...modalForm, area: e.target.value})} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold">
                    <option value="">Selecione...</option>
                    {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={executeModalAction} className="flex-1 bg-blue-600 text-white font-bold py-3.5 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30">Confirmar</button>
              <button onClick={()=>setActiveModal(null)} className="flex-1 bg-slate-100 text-slate-600 font-bold py-3.5 rounded-xl hover:bg-slate-200">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// OPS 3 VIEW (Supervisão)
// ==========================================
// ===== HORA A HORA (DOT) =====
// A janta de um Ops 2 bloqueia a hora? (janta pode virar a meia-noite)
function jantaBlocks(lb, h) {
  if (!lb || !lb.start || !lb.end) return false;
  const sH = parseInt(lb.start.slice(0, 2), 10), eH = parseInt(lb.end.slice(0, 2), 10);
  if (sH === eH) return sH === h;
  if (sH < eH) return h >= sH && h <= eH;
  return h >= sH || h <= eH; // virou a meia-noite
}

// Distribui os Ops 2 nos horarios 17h-23h evitando conflito com a janta
function autoDistributeDot(db) {
  const op2s = db.users.filter(u => {
    if (u.role !== 'OPLOG2' || u.status !== 'ATIVO') return false;
    // MAQUINA: Ops 2 alocado na MAQUINA nao entra na escala do DOT
    if (db.ops2Assignments[u.id] === 'MAQUINA') return false;
    // FOLGA: quem está de folga na escala da turma E não bateu ponto hoje fica de fora
    const temPonto = db.logs.some(l => l.name === u.name && l.date === db.todayStr);
    const naEscala = isWorkingDay(u.turma, db.todayStr);
    return temPonto || naEscala || (db.extraOps[u.id] && db.extraOps[u.id].extra);
  });
  const slots = {}; const counts = {};
  for (let h = 17; h <= 23; h++) {
    const free = op2s.filter(o => !jantaBlocks(db.lunchBreaks[o.id], h));
    const fresh = free.filter(o => !counts[o.id]);
    const pool = fresh.length ? fresh : free;
    if (!pool.length) { slots[h] = null; continue; }
    pool.sort((a, b) => (counts[a.id] || 0) - (counts[b.id] || 0));
    slots[h] = pool[0].id; counts[pool[0].id] = (counts[pool[0].id] || 0) + 1;
  }
  db.setDotSchedule({ date: db.todayStr, slots, v: 4 });
  db.showToast('Distribuicao do hora a hora atualizada: jantas e folgas da escala consideradas.', 'success');
}

function Ops3View({ currentUser, db }) {
  const requestAreaReport = (area) => {
    // MUDANÇA: com mais de um Ops 2 na área, o reporte chega para todos de uma vez
    const op2Ids = Object.keys(db.ops2Assignments).filter(k => db.ops2Assignments[k] === area);
    if (op2Ids.length === 0) return db.showToast("Nenhum Ops 2 delegado nesta área.", "error");
    const base = Date.now();
    const novos = op2Ids.map((op2Id, i) => ({
      id: base + i, area, ops3Name: currentUser.name, ops2Id: op2Id, requestTime: getTimeStr(), status: 'PENDING', text: ''
    }));
    db.setAreaReports([...db.areaReports, ...novos]);
    db.showToast(`Reporte urgente solicitado para a área ${area} (${op2Ids.length} Ops 2).`, "success");
  };

  const handleAssignOps2 = (ops2Id, area) => {
    const next = { ...db.ops2Assignments };
    // MUDANÇA: mais de um Ops 2 pode atuar na mesma área simultaneamente
    if (area) next[ops2Id] = area; else delete next[ops2Id];
    db.setOps2Assignments(next);
    db.showToast(area ? `Área ${area} delegada com sucesso.` : "Delegação removida.", "success");
  };

  const setExtra = (id, val) => {
    db.setExtraOps({ ...db.extraOps, [id]: { extra: val, at: Date.now() } });
    db.showToast(val ? 'Ops 2 marcado como EXTRA hoje (folga trabalhando).' : 'Marcação de EXTRA removida.', 'success');
  };

  // Ops 2 designado para cobrir a área durante a janta do dono
  const handleAssignCoverage = (area, op2Id) => {
    const next = { ...db.lunchCoverage };
    if (op2Id) next[area] = op2Id; else delete next[area];
    db.setLunchCoverage(next);
    db.showToast(op2Id ? `Cobertura de janta definida para ${area}.` : "Cobertura removida.", "success");
  };

  // HORA A HORA: garante escala do dia (regenera 1x por dia, sem sobrescrever ajustes manuais)
  useEffect(() => {
    if (!db.dotSchedule || db.dotSchedule.date !== db.todayStr || db.dotSchedule.v !== 4) autoDistributeDot(db);
    // eslint-disable-next-line
  }, [db.dotSchedule]);

  const closeSos = (sosId) => {
    db.setSosRequests(db.sosRequests.map(s => s.id === sosId ? { ...s, status: 'CLOSED' } : s));
    db.showToast("SOS encerrado.", "success");
  };

  const setLunch = (empId, role, start, end) => {
    if (!start && !end) return; // FIX: não registra janta vazia
    db.setLunchBreaks({ ...db.lunchBreaks, [empId]: { start, end, role } });
    db.showToast("Horário de janta registrado.", "success");
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Saturação (SOS) */}
      {(() => { const openSosList = db.sosRequests.filter(s => s.status === 'OPEN' || s.status === 'ACCEPTED'); return openSosList.length > 0 ? (
        <div className="bg-red-50 p-8 rounded-3xl shadow-sm border border-red-200">
          <h3 className="font-extrabold text-red-800 text-2xl mb-6 flex items-center gap-3"><AlertTriangle size={28}/> Painel Crítico de Saturação (SOS)</h3>
          <div className="space-y-4">
            {openSosList.map(sos => (
              <div key={sos.id} className={`bg-white p-6 rounded-2xl shadow-sm border-l-8 relative overflow-hidden ${sos.status === 'ACCEPTED' ? 'border-green-600' : 'border-red-600'}`}>
                <div className={`absolute top-0 right-0 text-white font-bold text-xs px-3 py-1 rounded-bl-lg ${sos.status === 'ACCEPTED' ? 'bg-green-600' : 'bg-red-600 animate-pulse'}`}>
                  {sos.status === 'ACCEPTED' ? 'APOIO A CAMINHO' : 'SOS ATIVO'}
                </div>
                <div className="font-black text-xl text-slate-800 mb-1">Área {sos.fromArea} pedindo ajuda!</div>
                <div className="text-sm text-slate-500 font-medium mb-4">Acionado pelo Ops 2: {sos.fromOpsName}</div>
                
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Monitoramento de Respostas da Rede</div>
                  {sos.responses.length === 0 ? <p className="text-sm text-slate-400 font-medium italic">Aguardando outros Ops responderem...</p> : (
                    <ul className="space-y-3">
                      {sos.responses.map((resp, i) => (
                        <li key={i} className="flex items-start gap-3 bg-white p-3 rounded-lg border border-slate-100 shadow-sm">
                          {resp.status === 'ACCEPTED' ? <CheckCircle className="text-green-500 mt-0.5" size={18}/> : <XCircle className="text-red-500 mt-0.5" size={18}/>}
                          <div>
                            <b className="text-slate-800">{resp.opsName}</b>
                            {resp.status === 'ACCEPTED' ? <span className="text-green-600 font-bold ml-2">Aceitou ajudar</span> : <span className="text-red-600 font-bold ml-2 block mt-1">Recusou: <span className="font-normal italic">"{resp.justification}"</span></span>}
                            {resp.status === 'ACCEPTED' && <span className="block text-slate-600 font-bold text-xs mt-1">Máquinas: {typeof resp.machines === 'number' ? resp.machines : 'não informado'} | Colaboradores: {(resp.helpers || []).join(', ') || 'não informados'}</span>}
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <button onClick={() => closeSos(sos.id)} className="mt-4 w-full bg-slate-800 hover:bg-slate-900 text-white py-3 rounded-xl font-bold text-sm transition-colors">Encerrar SOS</button>
              </div>
            ))}
          </div>
        </div>
      ) : null; })()}

      {/* Delegação e Supervisão */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Delegação Ops 2 */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="font-extrabold text-2xl text-slate-800 mb-6">Delegação de Áreas (Ops 2)</h3>
          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
            {db.users.filter(u => u.role === 'OPLOG2').map(op2 => (
              <div key={op2.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-lg"><Shield className="text-blue-600" size={20}/> {op2.name}</div>
                  {(() => { const f = !isWorkingDay(op2.turma, db.todayStr); const ex = db.extraOps[op2.id] && db.extraOps[op2.id].extra; return f ? (ex
                    ? <span className="bg-emerald-100 text-emerald-700 border border-emerald-300 px-2 py-0.5 rounded-full text-[10px] font-black">EXTRA HOJE (folga)</span>
                    : <span className="bg-red-100 text-red-700 border border-red-300 px-2 py-0.5 rounded-full text-[10px] font-black">FOLGA HOJE</span>) : null; })()}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Área Atribuída</label>
                    {(() => { const f2 = !isWorkingDay(op2.turma, db.todayStr); const ex2 = db.extraOps[op2.id] && db.extraOps[op2.id].extra; return f2 && !ex2; })() ? true : false} <select value={db.ops2Assignments[op2.id] || ''} onChange={e => handleAssignOps2(op2.id, e.target.value)} className="w-full p-3 border border-slate-300 rounded-xl font-bold text-slate-700 bg-white outline-none focus:border-blue-500">
                      <option value="">-- Indefinido --</option>
                      {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                    {(() => { const f3 = !isWorkingDay(op2.turma, db.todayStr); const ex3 = db.extraOps[op2.id] && db.extraOps[op2.id].extra;
                      return f3 ? (ex3
                        ? <button onClick={() => setExtra(op2.id, false)} className="mt-2 w-full bg-slate-200 hover:bg-slate-300 text-slate-700 py-2 rounded-xl text-[11px] font-black">Desmarcar Extra</button>
                        : <button onClick={() => setExtra(op2.id, true)} className="mt-2 w-full bg-amber-500 hover:bg-amber-600 text-white py-2 rounded-xl text-[11px] font-black animate-pulse">Está de EXTRA hoje (marcar)</button>) : null; })()}
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Janta (Ops 2)</label>
                    <div className="flex items-center gap-2">
                      <input type="time" defaultValue={db.lunchBreaks[op2.id]?.start||''} onBlur={e=>setLunch(op2.id,'OPLOG2',e.target.value,db.lunchBreaks[op2.id]?.end)} className="w-full p-3 border border-slate-300 rounded-xl bg-white outline-none focus:border-orange-500 text-sm font-semibold text-slate-700"/>
                      <span className="text-slate-300 font-bold">-</span>
                      <input type="time" defaultValue={db.lunchBreaks[op2.id]?.end||''} onBlur={e=>setLunch(op2.id,'OPLOG2',db.lunchBreaks[op2.id]?.start,e.target.value)} className="w-full p-3 border border-slate-300 rounded-xl bg-white outline-none focus:border-orange-500 text-sm font-semibold text-slate-700"/>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Review de Áreas */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col">
          <h3 className="font-extrabold text-2xl text-slate-800 mb-6">Review de Áreas (Reporte)</h3>
          <div className="space-y-4 flex-1 overflow-y-auto">
            {AREAS.map(area => {
              const op2Ids = Object.keys(db.ops2Assignments).filter(k => db.ops2Assignments[k] === area);
              const op2s = op2Ids.map(id => db.users.find(u => u.id === id)).filter(Boolean);
              const report = db.areaReports.find(r => r.area === area && r.status === 'PENDING');
              const lastReport = db.areaReports.filter(r => r.area === area && r.status === 'COMPLETED').pop();
              const cobertura = db.lunchCoverage[area] ? db.users.find(u => u.id === db.lunchCoverage[area]) : null;
              
              return (
                <div key={area} className="p-5 bg-slate-50 border border-slate-200 rounded-2xl">
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <div className="font-black text-lg text-slate-800 uppercase tracking-wide">{area}</div>
                      <div className="text-xs font-bold text-slate-500 mt-1">Ops 2: {op2s.length > 0
                        ? op2s.map((o, i) => <span key={o.id}>{i > 0 && ' • '}<span className="text-blue-600">{o.name}</span></span>)
                        : <span className="text-red-500">Indefinido</span>}</div>
                    </div>
                    {op2s.length > 0 && !report && (
                      <button onClick={() => requestAreaReport(area)} className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md">Exigir Status</button>
                    )}
                    {report && <span className="text-amber-600 bg-amber-100 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 animate-pulse border border-amber-200"><Clock size={14}/> Aguardando</span>}
                  </div>
                  <div className="mt-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Cobertura de Janta</label>
                    <select value={db.lunchCoverage[area] || ''} onChange={e => handleAssignCoverage(area, e.target.value)} className="w-full p-2 border border-slate-300 rounded-xl font-bold text-slate-700 bg-white text-sm outline-none focus:border-orange-500">
                      <option value="">-- Nenhuma --</option>
                      {db.users.filter(u => u.role === 'OPLOG2' && !op2Ids.includes(u.id)).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                    {cobertura && <p className="text-[10px] font-bold text-orange-600 mt-1"><Clock size={10} className="inline"/> {cobertura.name} cobre esta área na janta do dono</p>}
                  </div>

                  {lastReport && !report && (
                    <div className="mt-4 pt-4 border-t border-slate-200">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Última Devolutiva ({lastReport.responseTime}):</div>
                      <div className="text-sm text-slate-700 bg-white p-3 rounded-xl border border-slate-100 shadow-sm font-medium">"{lastReport.text}"</div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* ====== HORA A HORA (DOT) ====== */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex flex-wrap justify-between items-center mb-6 gap-3">
          <div>
            <h3 className="font-extrabold text-xl text-slate-800 flex items-center gap-3"><AlertTriangle className="text-red-600"/> Hora a Hora (DOT)</h3>
            <p className="text-sm text-slate-500 mt-1">Atualizacao de hora em hora (17h as 23h). A escala evita o horario de janta de cada Ops 2.</p>
          </div>
          <button onClick={() => autoDistributeDot(db)} className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-sm">Redistribuir (jantas)</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {[17, 18, 19, 20, 21, 22, 23].map(h => {
            const respId = db.dotSchedule && db.dotSchedule.date === db.todayStr ? (db.dotSchedule.slots[h] || '') : '';
            const resp = respId ? db.users.find(u => u.id === respId) : null;
            const rep = db.dotReports.find(r => r.date === db.todayStr && r.hour === h);
            return (
              <div key={h} className={`p-5 border-2 rounded-2xl ${rep ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-slate-100'}`}>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-black text-lg text-slate-800">{h}h</span>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${rep ? 'bg-emerald-600 text-white' : 'bg-amber-500 text-white'}`}>{rep ? 'ENVIADO ' + rep.filledAt : 'PENDENTE'}</span>
                </div>
                <select value={respId} onChange={(e) => { const slots = { ...((db.dotSchedule && db.dotSchedule.slots) || {}) }; slots[h] = e.target.value || null; db.setDotSchedule({ date: db.todayStr, slots }); }}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs font-bold bg-white mb-2">
                  <option value="">-- sem responsavel --</option>
                  {db.users.filter(u => u.role === 'OPLOG2' && u.status === 'ATIVO').map(o => {
                    const lb2 = db.lunchBreaks[o.id];
                    const temPonto2 = db.logs.some(l => l.name === o.name && l.date === db.todayStr);
                    const folgaHoje = !isWorkingDay(o.turma, db.todayStr);
                    const extraHoje = db.extraOps[o.id] && db.extraOps[o.id].extra;
                    const maquinaHoje = db.ops2Assignments[o.id] === 'MAQUINA';
                    const tag = temPonto2 ? 'trabalhando' : (extraHoje ? 'EXTRA hoje' : (folgaHoje ? 'FOLGA hoje' : 'sem ponto hoje'));
                    return <option key={o.id} value={o.id}>{o.name.split(' ')[0]} ({tag}){maquinaHoje ? ' [MAQUINA]' : ''} {lb2 && lb2.start ? `(janta ${lb2.start})` : ''}</option>;
                  })}
                </select>
                {rep ? (
                  <div className="text-xs text-slate-700 space-y-1 font-semibold">
                    <p>DOT hora: <b>{rep.dotHora}</b> | Acum.: <b>{rep.dotAcum || '-'}</b></p>
                    <p>Perdas hora: <b>{rep.perdasHora || 'Sem perdas'}</b> | Gerais: <b>{rep.perdasGerais || '-'}</b></p>
                    <p>Canalizacao: <b>{rep.canalizacao || '-'}</b></p>
                    {rep.motivo && <p>Motivo dispatched: {rep.motivo}</p>}
                    <p className="text-slate-400">por {rep.ops2Name} as {rep.filledAt}</p>
                  </div>
                ) : <p className="text-xs text-slate-400 italic">Aguardando preenchimento{resp ? ' de ' + resp.name.split(' ')[0] : ''}.</p>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// OPS 2 VIEW (Linha da Frente)
// ==========================================
function Ops2View({ currentUser, db }) {
  const myArea = db.ops2Assignments[currentUser.id];
  const [justification, setJustification] = useState('');
  const [modalData, setModalData] = useState(null); // { type, incidentId, sosId }
  
  if (!myArea) return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-center animate-fade-in">
      <div className="w-24 h-24 bg-slate-200 rounded-3xl flex items-center justify-center mb-6"><Clock className="text-slate-400" size={48}/></div>
      <h2 className="text-3xl font-extrabold text-slate-800">Aguardando Delegação</h2>
      <p className="text-slate-500 text-lg mt-2 font-medium">O Ops 3 ainda não atribuiu sua área neste turno.</p>
    </div>
  );

  const areaEmps = db.users.filter(u => u.area === myArea && u.role === 'COLABORADOR');
  const pendingReport = db.areaReports.find(r => r.ops2Id === currentUser.id && r.status === 'PENDING');
  const openSosFromOthers = db.sosRequests.filter(r => r.status === 'OPEN' && r.fromOpsName !== currentUser.name);

  const handleIncident = (emp, type) => {
    db.setIncidents([{
      id: Date.now(), type, empId: emp.id, area: myArea, status: 'OPEN', 
      startTime: getTimeStr(), date: db.todayStr, reporterName: currentUser.name
    }, ...db.incidents]);
    db.showToast(`Incidente ${type} registrado! Gestor notificado.`, "error");
  };

  const executeIncidentResolution = () => {
    if(!justification.trim()) return db.showToast("Preencha a justificativa.", "error");
    db.setIncidents(db.incidents.map(i => i.id === modalData.incidentId ? { ...i, status: 'CLOSED', endTime: getTimeStr(), justification } : i));
    setJustification('');
    setModalData(null);
    db.showToast("Colaborador reintegrado e justificado.", "success");
  };

  const triggerSOS = () => {
    // Pode acionar quantas vezes for necessário (cada acionamento é um SOS novo)
    db.setSosRequests([{ id: Date.now(), fromArea: myArea, fromOpsName: currentUser.name, status: 'OPEN', responses: [], date: db.todayStr }, ...db.sosRequests]);
    db.showToast("S.O.S DISPARADO NA REDE!", "error");
  };

  const respondReport = () => {
    if(!justification.trim()) return db.showToast("Descreva o status atual.", "error");
    db.setAreaReports(db.areaReports.map(r => r.id === pendingReport.id ? { ...r, status: 'COMPLETED', responseTime: getTimeStr(), text: justification } : r));
    setJustification('');
    db.showToast("Reporte enviado ao Ops 3.", "success");
  };

  const respondSos = (sosId, isAccepted) => {
    if(isAccepted) {
      // O apoio só é confirmado depois de informar máquinas e colaboradores
      setModalData({ type: 'SOS_ACCEPT', sosId, machines: '', helpers: [] });
    } else {
      setModalData({ type: 'SOS_REFUSE', sosId });
    }
  };

  const executeSosAccept = () => {
    const m = parseInt(modalData.machines, 10);
    if (isNaN(m) || m < 0) return db.showToast("Informe quantas máquinas vão apoiar.", "error");
    if (!modalData.helpers || modalData.helpers.length === 0) return db.showToast("Selecione pelo menos um colaborador que vai apoiar.", "error");
    db.setSosRequests(db.sosRequests.map(s => s.id === modalData.sosId
      ? { ...s, status: 'ACCEPTED', responses: [...s.responses, { opsName: currentUser.name, status: 'ACCEPTED', machines: m, helpers: modalData.helpers }] }
      : s));
    setModalData(null);
    db.showToast("SOS aceito! Máquinas e colaboradores informados à área.", "success");
  };

  const executeSosRefuse = () => {
    if(!justification.trim()) return db.showToast("Justifique a recusa.", "error");
    db.setSosRequests(db.sosRequests.map(s => s.id === modalData.sosId
      ? { ...s, responses: [...s.responses, { opsName: currentUser.name, status: 'REJECTED', justification }] }
      : s));
    setJustification('');
    setModalData(null);
  };

  const myLunch = db.lunchBreaks[currentUser.id];
  const [dotDrafts, setDotDrafts] = useState({}); // rascunhos do hora a hora

  // ===== HORA A HORA (DOT): meus horarios de hoje =====
  const myDotHours = (db.dotSchedule && db.dotSchedule.date === db.todayStr)
    ? Object.keys(db.dotSchedule.slots || {}).filter(h => db.dotSchedule.slots[h] === currentUser.id).map(Number).sort((a, b) => a - b)
    : [];

  const saveDot = (h) => {
    const f = dotDrafts[h] || {};
    if (!f.dotHora || !String(f.dotHora).trim()) return db.showToast("Informe o DOT da hora.", "error");
    const entry = { id: Date.now(), date: db.todayStr, hour: h, ops2Id: currentUser.id, ops2Name: currentUser.name,
      dotHora: String(f.dotHora).trim(), dotAcum: String(f.dotAcum || '').trim(), perdasHora: String(f.perdasHora || '').trim() || 'Sem perdas na hora.',
      perdasGerais: String(f.perdasGerais || '').trim(), canalizacao: String(f.canalizacao || '').trim(), motivo: String(f.motivo || '').trim(), filledAt: getTimeStr() };
    const others = db.dotReports.filter(r => !(r.date === db.todayStr && r.hour === h));
    db.setDotReports([...others, entry]);
    db.showToast(`DOT das ${h}h registrado!`, "success");
  };

  // ===== SINERGIA entre Ops 2 (igual a dos gestores) =====
  const pendingSins = db.sinergias.filter(si => si.toOps2Id === currentUser.id && si.status === 'PENDING' && si.date === db.todayStr);
  const respondSinergia = (id, accept) => {
    const req = db.sinergias.find(si => si.id === id);
    db.setSinergias(db.sinergias.map(si => si.id === id ? { ...si, status: accept ? 'ACCEPTED' : 'REJECTED' } : si));
    if (accept && req) {
      db.setUsers(db.users.map(u => u.id === req.empId ? { ...u, area: req.toArea, areaAt: Date.now() } : u));
      db.showToast(`Sinergia aceita. ${req.empName} movido para ${req.toArea}.`, "success");
    } else db.showToast("Sinergia recusada.", "error");
  };


  const doTransferOps2 = () => {
    const emp = db.users.find(u => u.id === modalData.empId);
    if (!emp || !modalData.toArea) return db.showToast("Selecione a area de destino.", "error");
    db.setUsers(db.users.map(u => u.id === emp.id ? { ...u, area: modalData.toArea, areaAt: Date.now() } : u));
    setModalData(null);
    db.showToast(`${emp.name.split(' ')[0]} transferido para ${modalData.toArea}.`, "success");
  };

  const devolverSinergia = (sinId) => {
    const sin = db.sinergias.find(s2 => s2.id === sinId);
    if (!sin) return;
    const destino = sin.fromArea || '';
    db.setUsers(db.users.map(u => u.id === sin.empId ? { ...u, area: destino, areaAt: Date.now() } : u));
    db.setSinergias(db.sinergias.map(s2 => s2.id === sinId ? { ...s2, status: 'RETURNED' } : s2));
    db.showToast(`Sinergia devolvida: ${sin.empName.split(' ')[0]} voltou para ${destino || 'sem área'}.`, "success");
  };

  const sendSinergiaOps2 = () => {
    const emp = db.users.find(u => u.id === modalData.empId);
    const toOp2 = db.users.find(u => u.id === modalData.toOps2Id);
    if (!emp || !toOp2 || !modalData.toArea) return db.showToast("Escolha a area e o Ops 2 de destino.", "error");
    db.setSinergias([...db.sinergias, { id: Date.now(), empId: emp.id, empName: emp.name,
      fromOps2: currentUser.name, fromOps2Id: currentUser.id, fromArea: myArea, toOps2: toOp2.name, toOps2Id: toOp2.id,
      toArea: modalData.toArea, status: 'PENDING', date: db.todayStr }]);
    setModalData(null);
    db.showToast(`Pedido de sinergia de ${emp.name.split(' ')[0]} enviado para ${toOp2.name.split(' ')[0]} (${modalData.toArea}).`, "success");
  };

  // Ops 2 define a janta dos operadores da sua área
  const setEmpJanta = (emp, start, end) => {
    const nb = { ...db.lunchBreaks };
    if (!start && !end) { delete nb[emp.id]; db.showToast("Janta do operador removida.", "success"); }
    else { nb[emp.id] = { start, end, role: 'COLABORADOR' }; db.showToast(`Janta de ${emp.name.split(' ')[0]} registrada.`, "success"); }
    db.setLunchBreaks(nb);
  };
  // Areas que este Ops 2 foi designado para cobrir na janta do dono
  const coberturaAreas = Object.keys(db.lunchCoverage || {}).filter(a => db.lunchCoverage[a] === currentUser.id);

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Sinergias recebidas de outros Ops 2 */}
      {pendingSins.length > 0 && (
        <div className="bg-amber-50 p-8 rounded-3xl shadow-sm border border-amber-200">
          <h3 className="font-bold text-amber-800 text-lg mb-4 flex items-center gap-2"><RefreshCw/> Sinergias Recebidas</h3>
          <div className="space-y-3">
            {pendingSins.map(req => (
              <div key={req.id} className="flex flex-col md:flex-row md:justify-between md:items-center gap-3 bg-white p-4 rounded-xl border border-amber-100 shadow-sm">
                <span className="text-slate-700">O Ops 2 <b>{req.fromOps2}</b> oferece o colaborador <b>{req.empName}</b> para a area <b>{req.toArea}</b>. Aceita?</span>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => respondSinergia(req.id, true)} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-bold">Aceitar</button>
                  <button onClick={() => respondSinergia(req.id, false)} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-bold">Recusar</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ====== HORA A HORA (DOT): meus horarios ====== */}
      {myDotHours.length > 0 && (
        <div className="bg-white p-8 rounded-3xl shadow-sm border-2 border-red-200">
          <h3 className="font-extrabold text-xl text-slate-800 mb-2 flex items-center gap-3"><AlertTriangle className="text-red-600"/> Hora a Hora (DOT)</h3>
          <p className="text-sm text-slate-500 mb-6">Voce e o responsavel pelas atualizacoes das <b>{myDotHours.map(h => h + 'h').join(', ')}</b>. Toda perda identificada deve ser canalizada imediatamente, informando a canalizacao e o motivo do dispatched.</p>
          {myDotHours.map(h => {
            const rep = db.dotReports.find(r => r.date === db.todayStr && r.hour === h);
            const v = (k) => (dotDrafts[h] && dotDrafts[h][k] !== undefined) ? dotDrafts[h][k] : (rep ? (rep[k] || '') : '');
            const set = (k, val) => setDotDrafts(d => ({ ...d, [h]: { ...(d[h] || {}), [k]: val } }));
            return (
              <div key={h} className={`p-5 rounded-2xl border-2 mb-4 ${rep ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
                <div className="flex justify-between items-center mb-3">
                  <span className="font-black text-lg text-slate-800">{h}h</span>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${rep ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>{rep ? 'ENVIADO ' + rep.filledAt : 'PENDENTE'}</span>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <input value={v('dotHora')} onChange={e => set('dotHora', e.target.value)} placeholder="DOT da hora" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500"/>
                  <input value={v('dotAcum')} onChange={e => set('dotAcum', e.target.value)} placeholder="DOT Acumulado" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500"/>
                  <input value={v('perdasHora')} onChange={e => set('perdasHora', e.target.value)} placeholder="Total de perdas da hora" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500"/>
                  <input value={v('perdasGerais')} onChange={e => set('perdasGerais', e.target.value)} placeholder="Perdas Gerais" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500"/>
                  <input value={v('canalizacao')} onChange={e => set('canalizacao', e.target.value)} placeholder="Canalizacao da hora" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500 col-span-2"/>
                  <input value={v('motivo')} onChange={e => set('motivo', e.target.value)} placeholder="Motivo Dispatched" className="p-3 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-blue-500 col-span-2"/>
                </div>
                <button onClick={() => saveDot(h)} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-3 rounded-xl shadow-lg">Registrar {h}h</button>
              </div>
            );
          })}
        </div>
      )}

      {/* Alerta de Reporte Ops 3 */}
      {pendingReport && (
        <div className="bg-red-600 text-white p-8 rounded-3xl shadow-2xl animate-pulse border-4 border-red-500/50 flex flex-col gap-4">
          <div className="font-extrabold text-2xl flex items-center gap-3"><AlertTriangle size={32}/> URGENTE: Reporte exigido pelo Ops 3!</div>
          <p className="text-red-100 font-medium">Informe imediatamente a situação da área, headcount e produtividade.</p>
          <div className="flex gap-4">
            <input type="text" value={justification} onChange={e=>setJustification(e.target.value)} placeholder="A área está operando com..." className="flex-1 text-slate-800 p-4 rounded-xl outline-none font-bold text-lg"/>
            <button onClick={respondReport} className="bg-white text-red-600 font-extrabold px-8 py-4 rounded-xl shadow-lg hover:scale-105 transition-transform">Enviar Status</button>
          </div>
        </div>
      )}

      {/* Meu S.O.S: status do que eu acioneei */}
      {(() => { const meusSos = db.sosRequests.filter(s => s.fromOpsName === currentUser.name && s.date === db.todayStr && s.status !== 'CLOSED'); return meusSos.length > 0 ? (
        <div className="bg-red-50 border-2 border-red-300 p-6 rounded-3xl shadow-sm">
          <h3 className="font-extrabold text-red-800 mb-4 flex items-center gap-2 text-xl"><Bell/> Meu S.O.S</h3>
          <div className="space-y-3">
            {meusSos.map(s => (
              <div key={s.id} className="bg-white p-5 rounded-2xl border border-red-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-black text-slate-800">SOS da área {s.fromArea}</span>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${s.status === 'ACCEPTED' ? 'bg-green-600 text-white' : 'bg-red-600 text-white animate-pulse'}`}>{s.status === 'ACCEPTED' ? 'APOIO A CAMINHO' : 'AGUARDANDO RESPOSTA'}</span>
                </div>
                {s.status === 'ACCEPTED' ? (
                  <div className="space-y-2">
                    {s.responses.filter(r => r.status === 'ACCEPTED').map((r, i) => (
                      <div key={i} className="bg-green-50 border border-green-200 p-3 rounded-xl">
                        <p className="font-bold text-green-800 text-sm">Apoio de {r.opsName}</p>
                        <p className="text-sm text-slate-700 font-semibold">Máquinas: {typeof r.machines === 'number' ? r.machines : '?'}</p>
                        <p className="text-sm text-slate-700 font-semibold">Colaboradores: {(r.helpers || []).join(', ') || 'não informados'}</p>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-sm text-slate-500 italic font-medium">Nenhum Ops 2 aceitou ainda. Acione de novo se precisar.</p>}
              </div>
            ))}
          </div>
        </div>
      ) : null; })()}

      {/* SOS de Outros */}
      {openSosFromOthers.length > 0 && (
        <div className="bg-amber-100 border border-amber-300 p-6 rounded-3xl shadow-sm">
          <h3 className="font-extrabold text-amber-800 mb-4 flex items-center gap-2 text-xl"><Bell/> SOS de Saturação na Rede</h3>
          <div className="space-y-3">
            {openSosFromOthers.map(sos => {
              if (sos.responses.some(r => r.opsName === currentUser.name)) return null;
              return (
                <div key={sos.id} className="flex justify-between items-center bg-white p-5 rounded-2xl shadow-sm border border-amber-50">
                  <span className="font-bold text-slate-800 text-lg">Área <b>{sos.fromArea}</b> pedindo apoio (Ops: {sos.fromOpsName})</span>
                  <div className="flex gap-3">
                    <button onClick={() => respondSos(sos.id, true)} className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl text-sm font-bold shadow">Vou Ajudar</button>
                    <button onClick={() => respondSos(sos.id, false)} className="bg-slate-800 hover:bg-slate-900 text-white px-6 py-3 rounded-xl text-sm font-bold shadow">Recusar</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Cobertura de Janta (designada pelo Ops 3) */}
      {coberturaAreas.length > 0 && coberturaAreas.map(cArea => {
        const donoId = Object.keys(db.ops2Assignments).find(k => db.ops2Assignments[k] === cArea);
        const dono = db.users.find(u => u.id === donoId);
        const donoLunch = dono ? db.lunchBreaks[dono.id] : null;
        const cobrindo = donoLunch && donoLunch.start && donoLunch.end;
        const agora = getTimeStr();
        const naJanta = cobrindo && donoLunch.start <= agora && agora <= donoLunch.end;
        const empsCob = db.users.filter(u => u.area === cArea && u.role === 'COLABORADOR');
        return (
          <div key={cArea} className={`p-6 rounded-3xl shadow-sm border-2 ${naJanta ? 'bg-orange-100 border-orange-400 animate-pulse' : 'bg-white border-orange-200'}`}>
            <h3 className="font-extrabold text-orange-800 mb-2 flex items-center gap-2 text-xl">🍽️ Cobertura de Janta: Área {cArea}</h3>
            <p className="text-sm text-slate-600 font-medium mb-3">
              Você foi designado pelo Ops 3 para cobrir esta área{dono ? ` durante a janta de ${dono.name}` : ''}{cobrindo ? ` (${donoLunch.start} - ${donoLunch.end})` : ''}.
              {naJanta ? ' O dono está na janta AGORA: acompanhe a área abaixo!' : ''}
            </p>
            {empsCob.length > 0 && (
              <div className="bg-white rounded-2xl border border-orange-100 p-4">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Colaboradores na Área ({empsCob.length})</div>
                {empsCob.map(e => <div key={e.id} className="text-sm font-bold text-slate-700 py-0.5">• {e.name}</div>)}
              </div>
            )}
          </div>
        );
      })}

      {/* Header da Área */}
      <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center bg-white p-8 rounded-3xl shadow-sm border border-slate-100 gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{myArea}</h2>
          <div className="flex items-center gap-4 mt-3">
            <span className="bg-blue-100 text-blue-800 px-4 py-1.5 rounded-full font-bold text-sm border border-blue-200">Headcount: {areaEmps.length}</span>
            {myLunch && <span className="bg-orange-100 text-orange-800 px-4 py-1.5 rounded-full font-bold text-sm border border-orange-200">Sua Janta: {myLunch.start} - {myLunch.end}</span>}
          </div>
        </div>
        <button onClick={triggerSOS} className="bg-red-600 hover:bg-red-700 text-white px-8 py-5 rounded-2xl font-black text-lg flex items-center justify-center gap-3 shadow-2xl shadow-red-600/40 transition-transform hover:scale-105">
          <AlertTriangle size={24}/> ACIONAR S.O.S
        </button>
      </div>

      {/* Lista de Colaboradores */}
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <h3 className="font-extrabold text-xl text-slate-800 mb-6 flex items-center gap-3"><Users className="text-blue-600"/> Linha de Frente</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {areaEmps.length === 0 ? <p className="text-slate-400 font-medium italic p-4">Nenhum colaborador alocado.</p> : null}
          {areaEmps.map(emp => {
            const openIncident = db.incidents.find(i => i.empId === emp.id && i.status === 'OPEN'); // FIX: vale para OCIOSIDADE e INDISCIPLINA
            const openIdle = db.incidents.find(i => i.empId === emp.id && i.type === 'OCIOSIDADE' && i.status === 'OPEN'); // realce ambar se ocioso
            const empLunch = db.lunchBreaks[emp.id];
            
            return (
              <div key={emp.id} className={`p-6 border-2 rounded-2xl flex flex-col justify-between transition-colors ${openIdle ? 'bg-amber-50 border-amber-300 shadow-md' : 'bg-slate-50 border-slate-100 hover:border-blue-200'}`}>
                <div className="mb-4">
                  <div className="flex items-center gap-4 mb-4">
                    <img src={emp.photo} className="w-14 h-14 rounded-full shadow-sm border border-slate-200" alt=""/>
                    <div>
                      <div className="font-extrabold text-slate-800 text-lg leading-tight">{emp.name}</div>
                      <div className="text-sm font-semibold text-slate-500 mt-1">TL: {emp.gestor}</div>
                    </div>
                  </div>
                  
                  {empLunch && (
                    <div className="text-xs font-black bg-orange-100 text-orange-800 px-3 py-1.5 rounded-lg inline-block mb-2 border border-orange-200">
                      Janta: {empLunch.start} - {empLunch.end}
                    </div>
                  )}
                  <div data-janta={emp.id} className="mb-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Janta do operador (Ops 2)</label>
                    <div className="flex gap-2 items-center">
                      <input type="time" defaultValue={empLunch?.start || ''} onBlur={(e) => { const c = e.target.closest('[data-janta]'); const [i1, i2] = c.querySelectorAll('input'); setEmpJanta(emp, i1.value, i2.value); }}
                        className="flex-1 p-2 border border-slate-300 rounded-lg bg-white outline-none focus:border-orange-500 text-sm font-semibold text-slate-700"/>
                      <span className="text-xs font-black text-slate-400">ATÉ</span>
                      <input type="time" defaultValue={empLunch?.end || ''} onBlur={(e) => { const c = e.target.closest('[data-janta]'); const [i1, i2] = c.querySelectorAll('input'); setEmpJanta(emp, i1.value, i2.value); }}
                        className="flex-1 p-2 border border-slate-300 rounded-lg bg-white outline-none focus:border-orange-500 text-sm font-semibold text-slate-700"/>
                    </div>
                  </div>

                  {(() => { const sinAcc = db.sinergias.find(s2 => s2.empId === emp.id && s2.status === 'ACCEPTED' && s2.toOps2Id === currentUser.id && s2.date === db.todayStr); if (!sinAcc) return null; return (
                    <div className="mb-3 p-3 rounded-xl bg-indigo-50 border border-indigo-200">
                      <p className="text-[10px] font-black text-indigo-800 uppercase tracking-widest mb-2">Sinergia recebida (veio de {sinAcc.fromArea || 'origem desconhecida'})</p>
                      <button onClick={() => devolverSinergia(sinAcc.id)} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl text-xs font-bold shadow-sm">Devolver Sinergia {sinAcc.fromArea ? `para ${sinAcc.fromArea}` : ''}</button>
                    </div>
                  ); })()}

                  {openIncident && (
                    <div className="bg-red-100 text-red-800 p-3 rounded-xl text-sm font-black border border-red-200 flex items-center gap-2">
                      <Clock size={16}/> {openIncident.type === 'OCIOSIDADE' ? `Sumido desde ${openIncident.startTime}` : `Indisciplina desde ${openIncident.startTime}`}
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-3 mt-auto">
                  {!openIncident ? (
                    <>
                      <button onClick={() => handleIncident(emp, 'OCIOSIDADE')} className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3 rounded-xl text-xs font-bold shadow-sm">Ocioso / Sumiu</button>
                      <button onClick={() => handleIncident(emp, 'MAL_COMPORTAMENTO')} className="flex-1 bg-slate-800 hover:bg-slate-900 text-white py-3 rounded-xl text-xs font-bold shadow-sm">Indisciplina</button>
                      <button onClick={() => setModalData({ type: 'SINERGIA_OPS2', empId: emp.id, toArea: '', toOps2Id: '' })} className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl text-xs font-bold shadow-sm">Sinergia</button>
                      <button onClick={() => setModalData({ type: 'TRANSFER_OPS2', empId: emp.id, toArea: '' })} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-xs font-bold shadow-sm">Transferir Área</button>
                    </>
                  ) : (
                    <button onClick={() => setModalData({ type: 'RESOLVE_IDLE', incidentId: openIncident.id })} className="w-full bg-green-600 hover:bg-green-700 text-white py-3.5 rounded-xl text-base font-black shadow-lg">
                      Registrar Retorno (Justificar)
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Modal Sinergia entre Ops 2 */}
      {modalData && modalData.type === 'TRANSFER_OPS2' && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4 z-[100] animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
            <h3 className="text-2xl font-extrabold text-slate-800 mb-2">Transferir de Área</h3>
            <p className="text-sm text-slate-500 font-medium mb-6">Corrigir a área de <b>{db.users.find(u => u.id === modalData.empId)?.name}</b> (atualmente em <b>{myArea}</b>). A mudança é imediata.</p>
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-1">Área correta</label>
            <select value={modalData.toArea} onChange={(e) => setModalData(m => ({ ...m, toArea: e.target.value }))} className="w-full p-3 border-2 border-slate-200 rounded-xl mb-6 font-bold text-slate-700 bg-white">
              <option value="">Selecione a área...</option>
              {AREAS.filter(a => a !== myArea).map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <div className="flex gap-4">
              <button onClick={doTransferOps2} className="flex-1 bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-700 shadow-lg">Transferir</button>
              <button onClick={() => setModalData(null)} className="flex-1 bg-slate-100 text-slate-600 font-black py-4 rounded-xl hover:bg-slate-200">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {modalData && modalData.type === 'SOS_ACCEPT' && (() => { const sosAlvo = db.sosRequests.find(s => s.id === modalData.sosId); return (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4 z-[100] animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
            <h3 className="text-2xl font-extrabold text-slate-800 mb-3">Apoiar Área {sosAlvo ? sosAlvo.fromArea : ''}</h3>
            <p className="text-sm text-slate-500 font-medium mb-6">Informe o apoio que você vai enviar. A área solicitante e o Ops 3 vão ver na hora.</p>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Quantas máquinas vão?</label>
            <input type="number" min="0" value={modalData.machines}
              onChange={e => setModalData({ ...modalData, machines: e.target.value })}
              className="w-full p-4 border-2 border-slate-200 rounded-2xl text-2xl font-black text-center outline-none focus:border-green-500 mb-6" placeholder="0"/>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Quais colaboradores vão apoiar? (sua linha de frente)</label>
            <div className="space-y-2 mb-6 max-h-52 overflow-y-auto">
              {areaEmps.length === 0 ? <p className="text-sm text-slate-400 italic">Nenhum colaborador na sua linha de frente.</p> : null}
              {areaEmps.map(emp => {
                const marcado = (modalData.helpers || []).includes(emp.name);
                return (
                  <label key={emp.id} className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-colors ${marcado ? 'bg-green-50 border-green-500' : 'bg-slate-50 border-slate-200'}`}>
                    <input type="checkbox" checked={marcado}
                      onChange={() => setModalData({ ...modalData, helpers: marcado ? modalData.helpers.filter(n2 => n2 !== emp.name) : [...modalData.helpers, emp.name] })}
                      className="w-5 h-5 accent-green-600"/>
                    <span className="font-bold text-sm text-slate-800">{emp.name}</span>
                  </label>
                );
              })}
            </div>
            <div className="flex gap-3">
              <button onClick={executeSosAccept} className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3.5 rounded-xl font-black shadow-lg">Enviar Apoio</button>
              <button onClick={() => setModalData(null)} className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-800 py-3.5 rounded-xl font-bold">Cancelar</button>
            </div>
          </div>
        </div>
      ); })()}

      {modalData && modalData.type === 'SINERGIA_OPS2' && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4 z-[100] animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full">
            <h3 className="text-2xl font-extrabold text-slate-800 mb-2">Sinergia de Colaborador</h3>
            <p className="text-sm text-slate-500 font-medium mb-6">Enviar <b>{db.users.find(u => u.id === modalData.empId)?.name}</b> para outra area. O Ops 2 responsavel pela area de destino precisa aceitar.</p>
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-1">Area de destino</label>
            <select value={modalData.toArea} onChange={(e) => {
              const area = e.target.value;
              const respId = Object.keys(db.ops2Assignments).find(k => db.ops2Assignments[k] === area) || '';
              setModalData(m => ({ ...m, toArea: area, toOps2Id: respId }));
            }} className="w-full p-3 border-2 border-slate-200 rounded-xl mb-4 font-bold text-slate-700 bg-white">
              <option value="">Selecione a area...</option>
              {AREAS.filter(a => a !== myArea).map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-1">Ops 2 de destino</label>
            <select value={modalData.toOps2Id} onChange={(e) => setModalData(m => ({ ...m, toOps2Id: e.target.value }))} className="w-full p-3 border-2 border-slate-200 rounded-xl mb-6 font-bold text-slate-700 bg-white">
              <option value="">Selecione o Ops 2...</option>
              {db.users.filter(u => u.role === 'OPLOG2' && u.status === 'ATIVO' && u.id !== currentUser.id).map(o => {
                const a = db.ops2Assignments[o.id];
                return <option key={o.id} value={o.id}>{o.name.split(' ')[0]}{a ? ` (${a})` : ''}</option>;
              })}
            </select>
            <div className="flex gap-4">
              <button onClick={sendSinergiaOps2} className="flex-1 bg-emerald-600 text-white font-black py-4 rounded-xl hover:bg-emerald-700 shadow-lg">Enviar Sinergia</button>
              <button onClick={() => setModalData(null)} className="flex-1 bg-slate-100 text-slate-600 font-black py-4 rounded-xl hover:bg-slate-200">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Reutilizável */}
      {modalData && (modalData.type === 'RESOLVE_IDLE' || modalData.type === 'SOS_REFUSE') && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-4 z-[100] animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl p-10 max-w-md w-full">
            <h3 className="text-2xl font-extrabold text-slate-800 mb-3">
              {modalData.type === 'SOS_REFUSE' ? 'Justificar Recusa' : 'Justificar Retorno'}
            </h3>
            <p className="text-sm text-slate-500 font-medium mb-6">
              {modalData.type === 'SOS_REFUSE' ? 'Por que você não pode apoiar a área solicitante?' : 'Por que o colaborador estava fora da área de operação?'}
            </p>
            
            <textarea 
              value={justification} 
              onChange={e=>setJustification(e.target.value)} 
              className="w-full p-5 border-2 border-slate-200 rounded-2xl bg-slate-50 outline-none focus:border-blue-500 focus:bg-white resize-none h-32 mb-6 font-medium text-slate-800"
              placeholder="Descreva detalhadamente..."
              autoFocus
            />
            
            <div className="flex gap-4">
              <button onClick={modalData.type === 'SOS_REFUSE' ? executeSosRefuse : executeIncidentResolution} className="flex-1 bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30 transition-transform hover:scale-105">Confirmar</button>
              <button onClick={() => { setModalData(null); setJustification(''); }} className="flex-1 bg-slate-100 text-slate-600 font-black py-4 rounded-xl hover:bg-slate-200 transition-colors">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// COMPONENTE SHARED: HISTÓRICO DE INCIDENTES (Mestre/Gestor)
// ==========================================
function IncidentsHistory({ db, role, gestorId }) {
  const visibleIncidents = db.incidents.filter(inc => {
    if (role === 'MASTER') return true;
    const emp = db.users.find(u => u.id === inc.empId);
    return emp?.gestorId === gestorId;
  });

  if (visibleIncidents.length === 0) return null;

  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm border-t-8 border-red-800 mt-8 animate-fade-in">
      <h3 className="font-extrabold text-2xl mb-6 text-red-800 flex items-center gap-3"><FileText size={28}/> Histórico Restrito de Indisciplina</h3>
      <div className="overflow-x-auto border border-slate-200 rounded-2xl">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] font-black border-b border-slate-200 tracking-wider">
            <tr>
              <th className="p-5">Data e Início</th>
              <th className="p-5">Colaborador / TL</th>
              <th className="p-5">Tipo</th>
              <th className="p-5">Ops Responsável</th>
              <th className="p-5">Status e Justificativa</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {visibleIncidents.map(inc => {
              const emp = db.users.find(u => u.id === inc.empId);
              return (
                <tr key={inc.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-5 font-bold text-slate-600">{inc.date} <br/><span className="text-lg text-slate-800">{inc.startTime}</span></td>
                  <td className="p-5">
                    <div className="font-bold text-slate-800 text-base">{emp?.name}</div>
                    <div className="text-xs font-semibold text-slate-500 mt-1">TL: {emp?.gestor}</div>
                  </td>
                  <td className="p-5">
                    <span className={`px-3 py-1.5 rounded-lg text-xs font-black text-white ${inc.type==='OCIOSIDADE'?'bg-amber-500':'bg-slate-800'}`}>
                      {inc.type}
                    </span>
                  </td>
                  <td className="p-5 font-bold text-slate-700">{inc.reporterName} <br/><span className="text-xs font-medium text-slate-500">({inc.area})</span></td>
                  <td className="p-5">
                    {inc.status === 'OPEN' ? (
                      <span className="text-red-500 font-bold text-sm flex items-center gap-2 animate-pulse"><Clock size={16}/> Em Aberto...</span>
                    ) : (
                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="text-green-600 font-black text-xs block mb-1">Encerrado: {inc.endTime}</span>
                        <span className="text-slate-600 font-medium italic text-sm">"{inc.justification}"</span>
                      </div>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
